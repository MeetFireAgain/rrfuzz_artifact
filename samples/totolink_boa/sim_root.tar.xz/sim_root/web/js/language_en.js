//------------------------------------
//---status---
var Js_Access_Point="Status";
var Js_System="System Information";
var Js_Information="Information";
var Js_Uptime="Uptime";
var Js_Version="Version";
var status_max_sessions = 'Max sessions';
var status_curr_sessions ='Current sessions';
var cpuinfo="CPU Load";
var meminfo="SDRAM Utilization";
var Js_GetIpMode="Connection Type";
var Js_Ipv6LanSet="IPv6 LAN";
var Js_Global_Addr="Global Address";
var Js_LL_Addr="LL Address";
var Js_Ipv6WanSet="IPv6 WAN";
var Js_Ipv6WanLinkType="Link Type";
var Status_RootMode="Root AP";
var Status_wifi_config = 'Wi-Fi Configuration';
var Js_RootMode="Wireless";
var Js_wifiMode="Wireless";
var Js_StuHelpMsg="This page shows the current status and some basic settings of the device.";
//var Status_Mode="Mode";
var Js_Infra_Client="Infrastructure Client";
var Js_Ad_hoc_Client="Ad-hoc Client";
//var Js_Status_Band="Band";
//var Js_Status_Channel="Channel Number";
var Js_Associated_Client="Connected Clients";
var Js_State="State";
var Js_Signal="Signal";
var tcpip_wan_conn = 'Connect';
var tcpip_wan_disconn = 'Disconnect';
var status_need_setlanip = "IP address conflict! Please change the IP address in “LAN Settings”";
var MM_StatusLan="LAN";

//-----stats------
var stat_Statistics="Statistics";
var stat_SentPack="Root AP Sent Packets";
var stat_RcvPack="Root AP Received Packets";
var stat_ClientSentPack="Wireless Client Sent Packets";
var stat_ClientRcvPack="Wireless Client Received Packets";
//var stat_VirtualAP="Virtual AP";

var status_secondary_connection = 'Secondary Connection';
var status_secondary_ip = 'IP Address';
var status_secondary_subnet_mask = 'Subnet Mask';
var status_secondary_connect_type = 'WAN DHCP Type';
//-----wizard-----
var MM_EasyWizard="Easy Setup";
//var MM_UserName="User Name";
var MM_UserPassWd="User Password";
var MM_OperationMode="Operation mode";
var MM_GatewayMode="Gateway";
var wizard_WISPMode="Wireless ISP";
var wizard_RepeaterMode="Bridge Repeater";
var wizard_RepeaterInt="Repeater Client interface";
//var wizard_WirelessClinet5G="Wireless Client - 5GHz";
//var wizard_WirelessClinet2_4="Wireless Client - 2.4GHz";
var wizard_RepeaterClinet="Repeater Client";
//var wizard_WirelessAp="Root AP";
var wizard_Encryptionkey="Password";
var wizard_WanPhytype="Wan phy type";
var wizard_Dialnum="Dial Number:";
var wizard_LanIpAddr="LAN IP Address";

var enable_mac_clone="MAC address clone";
var wlan_enable_mac_clone="Enable MAC address cloning";
var MM_ChangeSetting="Being processed";
var MM_PleaseWait="Please wait";
var MM_seconds="seconds";

var MM_CrrentDevice="Current Device";
var MM_DeviceName="Device Name";
//var wizard_NoEncryption="Disable";
/***********	opmode.htm	************/
//var menu_opmode ='Operation Mode';
var opmode_radio_gw_explain='The device enables multiple users to share Internet via ADSL/Cable Mode. The wireless connection share the same IP to ISP through Ethernet WAN port.';
var MSG_opmode_gw_explain='Quickly configure the router to access the Internet.';
var opmode_radio_br='AP Mode';
var opmode_radio_ap='AP Mode';
var MM_RepeaterMode="Repeater(Extender)";
var MM_MeshMode="Mesh Mode";
var MM_Mesh="Mesh";
var MSG_MeshMode="In this mode, smart networking can be implemented between our devices.";
var MSG_RepeaterMode="Transform your existing wired network to a wireless network,Repeater's wireless password will be the same as the Primary Router.";

var opmode_radio_ap_explain='Extend your existing wireless coverage by relaying wireless signal.';
var opmode_radio_br_explain='In this mode, the device is used as an Access Point and all ports  become LAN ports. It will access the Internet by wired connection to upper router. All the WAN related functions and firewall are not supported.';
var opmode_radio_wisp='WISP Mode';
var opmode_radio_wisp_explain='In this mode, the device enables multiple users to access the Internet from WISP. All connected terminals share the same IP through wireless connection.';
var opmode_radio_wisp_wanif='WAN Interface  ';
/***********	gateway_mode.htm	************/
var Js_GateWayTitle="Gateway Mode";
var Js_GatewayConType="Internet Connection Type";
var Js_GateWayHelpMsg="The device enables multiple users to share Internet via ADSL/Cable Mode. The wireless connection share the same IP to ISP through Ethernet WAN port.";
var Js_SecondConnect ="Secondary Connection";
var Js_DomainName="VPN Server IP/Domain Name";
var Js_OperatCloneMacAddr="Clone Current PC MAC Address";
var Js_BackButton="Back";
var Js_NextButton="Next";
var Js_GateWayNote="Note:";
var Js_GateWaydhcpFootnote="Connect the DHCP server device to share the internet";
var Js_GateWayppoeFootnote="Enter your username and password, provided by your Internet service provider (ISP)";
var Js_GateWaystaticFootnote="Information such as the IP address, subnet mask, gateway and DNS to be entered into the WAN port is provided by your Internet Service Provider (ISP)";
var Js_GateWaypptpFootnote="Information such as the IP address, subnet mask, gateway and DNS to be entered into the WAN port is provided by your Internet Service Provider (ISP)";
var Js_GateWayl2tpFootnote="Information such as the IP address, subnet mask, gateway and DNS to be entered into the WAN port is provided by your Internet Service Provider (ISP)";
var Js_WirelessTitle="Wireless Network";
var Js_Wirelesspwlength="(length range is 8-63)";
var Js_PrimaryDNS="Primary DNS";
var Js_SecondDNS="Secondary DNS";
var Js_PppoePwdErr="Confirmed  password cannot be empty!";
var Js_PppoePwdNoSame="Confirm password and password are not the same!";
var Js_DomainEmapy="Domain name can not be empty,please try again";
var Js_InvalidGatewayMsg="Invalid gateway address!\nIt should be located in the same subnet of current IP address.";
/***********  repeater_mode.htm	************/
var Js_RepeaterTitle="Repeater(Extender)";
var Js_RepeaterExplain="Transform your existing wired network to a wireless network，Repeater's wireless password will be the same as the Primary Router";
var Js_RouteType="Primary Router Wireless Type";
var Js_Primaryssid="Primary Router SSID";
var Js_PrimaryPwd="Primary Router Password";
var Js_Repeater5ssid="Repeater 5GHz SSID";
var Js_Repeater2_4ssid="Repeater 2.4GHz SSID";
var Js_WEPPwdNote="(WEP passphrase  should be 5 or 13 characters.)";
var Js_Invaildeppwdlen="Wep mode password length setting must be 5 or 13 characters.";
var Js_Primempty="Primary Router SSID is not empty!";
var Js_PrimePwd="Primary Router Password is not empty!";
var Js_Repeater5="Repeater 5GHz SSID is not empty!";
var Js_Repeater2_4="Repeater 2.4GHz SSID is not empty!";
/***********  ap_mode.htm ************/
var Js_ApModeTitle="AP Mode";
var Js_ApModeExplain="Extend your existing wireless coverage by relaying wireless signal.";
/**********  wisp_mode.htm ***********/
var Js_WispModeTitle="WISP Mode";
var Js_WispModeExpain="In this mode, the device enables multiple users to access the Internet from WISP. All connected terminals share the same IP through wireless connection.";

// wlan basic
var Js_Wlan_ssid="SSID";
var Js_Wlan_Title="Basic Settings";
var Js_Wlan_AceCtr="Access Control";
var Js_WLan_Up="Upload:";
var Js_WLan_Down="Download:";
var Js_Wlan_Auth="Authentication";
var Js_Wlan_OpenSys="Open System";
var Js_Wlan_KeyLen="Key Length";
var Js_Wlan_Enterprise="Enterprise";
var Js_Wlan_Personal="Personal (Pre-Shared Key)";
var Js_Wlan_WpaKit="WPA Cipher Suite";
var Js_Wlan_Wpa2Kit="WPA2 Cipher Suite";
var Js_Wlan_ManagePro="Management Frame Protection";
//var Js_Wlan_disable="disable";
//var Js_Wlan_enable="enable";
var Js_Wlan_Hexcharacters="HEX (64 characters)";
//var Js_Wlan_EAPType="EAP Type";
var Js_Wlan_TunnelType="Inside Tunnel Type";
//var Js_Wlan_EAPUserID="EAP User ID";
var Js_Wlan_UserKeyPassword="User Key Password";
var Js_WlanBsicHelpMsg="This page is used to configure the parameters for wireless LAN clients which may connect to your Access Point. Here you may change wireless encryption settings as well as wireless network parameters.";
var MM_NoEncry="Disable";
var MM_WPAMixed="WPA-Mixed";
var MM_RadiusError="RADIUS Server port number cannot be empty! It should be a decimal number between 1-65535.";
var MM_ClientLimit="Invalid value of Limit Client. Input value should be between 1-32 in decimal.";
var MM_Wps2Disable="if WEP is turn on,WPS2.0 will be disabled.";
var MM_Set="";
var MM_IAPP="IAPP";
var MM_Protection="Protection";
var MM_Aggregation="Aggregation";
var MM_ShortGi="Short GI";
var MM_WLANPartition="WLAN Partition";
var MM_TxBeam="Tx Beamforming";
var MM_Rserror1="No RS port number!";
var util_invalid_key_length = 'Invalid length of Key ';
var util_should_be = 'It should be ';
var util_char = ' Characters.';
var util_invalid_value = ' Value. ';
//var Js_Show_Client="Show Clients";
// wlan advanced
var Js_Wlan_AdvancTitle="Advanced Settings";
//var Js_Wlan_AdvancRootAp="Root AP is Disabled !"
var Js_Wlan_Country="Region";
var Js_Wlan_EnMacClon="Enable Mac Clone";
var Js_Wlan_EnRepeater="Enable Universal Repeater";
var Js_Wlan_ExtInSID="Extended interface SSID";
var Js_Wlan_EnWirPro="Enable Wireless Profile";
var Js_Wlan_WirProList="Wireless Profile List";
//var Js_Wlan_Protection="Protection";
//var Js_Wlan_Aggregation="Aggregation";
//var Js_Wlan_ShortGi="Short GI";
//var Js_Wlan_Partition="WLAN Partition";
//var Js_Wlan_Coexist="20/40MHz Coexist";
//var Js_Wlan_Beamform="TX Beamforming";
var Js_Wlan_Mut2Un="Mutilcast to Unicast";
var Js_Wlan_Prohibit="TDLS Prohibited";
var Js_Wlan_ChaProhibit="TDLS Channel Switch Prohibited";
var Js_Wlan_MutRate="Mutilcast Rate";
var Js_Wlan_OutPower="RF Output Power";
var Js_80211kSupport="802.11k Support";
var Js_Wlan_CrossSpt="Crossband Support";
var Js_Wlan_FastSport="Fast BSS Transition Support";
var Js_Wlan_OverDSSpt="Support Over-the-DS";
var Js_80211vSupport="802.11v BSS Transition Support";
var Js_SmartRoam="Smart Roaming Support";
var Js_Wlan_StaCtl="Enable STA Control";
var Js_wlan_OnDhcpClient="Client";
var Js_wlan_OnDhcpServer="Server";
var Js_Prefer="Prefer";
var Js_WladvHelpMsg="These settings are only for more technically advanced users who have a sufficient knowledge about wireless LAN. These settings should not be changed unless you know what effect the changes will have on your Access Point.";
var wlbasic_broadcastssid= 'Broadcast SSID';
var wlbasic_brossid_enabled = 'Enabled';
var wlbasic_brossid_disabled = 'Disabled';
//var Js_Prefer2GHz="Prefer 2GHz";
/**********   wlstatbl.htm   **********/
var Js_Wlstatbl="Active Wireless Client";
/**********   wlactrl.htm   **********/
var Js_WireAccessCtl="Access Control";
var Js_RootApDisable="Root AP is Disabled !";
//var Js_WireAcsCtlMode="Wireless Access Control Mode";
var Js_AllowList="Allow Listed";
var Js_DenyList="Deny Listed";
var Js_CurAcsCtl="Current Access Control List";
var Js_WlactrlHelpMsg="If you choose 'Allowed Listed', only those clients whose wireless MAC addresses are in the access control list will be able to connect to your Access Point. When 'Deny Listed' is selected, these wireless clients on the list will not be able to connect the Access Point."
// wlan WDS
var Js_WDSSet="WDS Settings";
var Js_WDSEncrypMode="WDS Encryption Mode";
var Js_PreShareKey="Pre-Shared Key";
var Js_PreKeyformat="Pre-Shared Key Format";
var Js_TxRate="Tx Rate (Mbps)";
var Js_WlWdsHelpMsg="Wireless Distribution System uses wireless media to communicate with other APs, like the Ethernet does. To do this, you must set these APs in the same channel and set MAC address of other APs which you want to communicate with in the table and then enable the WDS.";
/***********	wlwdstbl.htm ************/
var Js_WdsTablHeader = "WDS AP Table"
var Js_WdsTx_pkt = "Tx Packets";
var Js_WdsTbl_Tx_Err = "Tx Errors";
var Js_WdsTbl_Rx_Pkt = "Rx Packets";
var Js_WdsTbl_Tx_Rate = "Tx Rate (Mbps)";
var Js_WdsTbl_Refresh = "Refresh";
/***********   wlsurvey.htm   ***********/
var Js_Wlanloop="loop 3 times!";
var wlsurvey_inside_nosupport = 'This inside type is not supported.';
var wlsurvey_eap_nosupport = 'This EAP type is not supported.';
var wlsurvey_wrong_method ="wrong method!";
var wlsurvey_id_nosupport="Error: not supported method id ";
var wlsurvey_Key_Type="Key Type";
var wlsurvey_keytype_shared = 'Shared';
var wlsurvey_keytype_both = 'Both';
var wlsurvey_keylen = 'Key Length';
var wlsurvey_keylen_64 = '64-bit';
var wlsurvey_keylen_128 = '128-bit';

var wlsurvey_keyfmt = 'Key Format';
var wlsurvey_keyfmt_ascii = 'ASCII';
var wlsurvey_keyfmt_hex = 'Hex';
var wlsurvey_keyset = 'Key Setting'

var wlsurvey_authmode = 'Authentication Mode';
var wlsurvey_authmode_enter_radius = 'Enterprise (RADIUS)';
var wlsurvey_authmode_enter_server = 'Enterprise (AS Server)';
var wlsurvey_authmode_personal = 'Personal (Pre-Shared Key)';
var wlsurvey_wpacip = 'WPA Cipher Suite';
var wlsurvey_wpacip_tkip = 'TKIP';
var wlsurvey_wpacip_aes = 'AES';
var wlsurvey_wp2chip = 'WPA2 Cipher Suite';
var wlsurvey_wp2chip_tkip = 'TKIP';
var wlsurvey_wp2chip_aes = 'AES';
var wlsurvey_preshared_keyfmt = 'Pre-Shared Key Format';
var wlsurvey_preshared_keyfmt_passphrase = 'Passphrase';
var wlsurvey_preshared_keyfmt_hex = 'HEX (64 characters)';
var wlsurvey_preshared_key = 'Pre-Shared Key';
var wlsurvey_eaptype = 'EAP Type';
var wlsurvey_intunn_type = 'Inside Tunnel Type';
var wlsurvey_intunn_type_MSCHAPV2 = 'MSCHAPV2';
var wlsurvey_eap_userid = 'EAP User ID';
var wlsurvey_radius_passwd = 'RADIUS User Password';
var wlsurvey_radius_name = 'RADIUS User Name';
var wlsurvey_user_keypasswd = 'User Key Password (if any)';
var wlsurvey_Client_inface="Site Survey";
var wlsurvey_help_msg="This page provides tool to scan the wireless network. If any Access Point or IBSS is found, you could choose to connect it manually when client mode is enabled.";
// wlan WPS
var Js_WpsHelspMsg="This page allows you to change the setting for WPS (Wi-Fi Protected Setup). Using this feature could let your wireless client automically syncronize its setting and connect to the Access Point in a minute without any hassle.";
var Js_WlanProtectSetup="WPS Settings";
var Js_WpsStu="WPS Status";
var Js_ResetUnCfg="Reset to UnConfigured";
var Js_AutoDownstate="Auto-lock-down state";
var Js_SelfPinNumber="Self-PIN Number";
var Js_RegistrarMac="Assign Mac of Registrar";
var Js_RegistrarSsid="Assign SSID of Registrar";
var Js_PushBtonCfg="Push Button Configuration";
var Js_ClientPinNum="Client PIN Number";
var Js_CurrentKeyInfo="Current Key Info";
var Js_Open="Open";
var Js_WepShared="WEP Shared";
var wlwps_regenerate_pin = 'Regenerate PIN & Apply';
// wlan schedule
var Js_WireSchedule="Wireless Schedule";
var Js_LanInfcSetup="LAN Settings";
var Js_TimeExpired="Time Expired(s)";
var Js_WlSchHelpMsg="This page allows you setup the wireless schedule rule. Please do not forget to configure system time before enable this feature.";
/******************Tcp/IP*****************/
var Js_SpannTree="802.1d Spanning Tree";
var Js_CloneMACAddr="Clone MAC Address";
var Js_ReservedStaticIp="Reserved Static IP";
var Js_EnIGMPProxy="Enable IGMP Proxy";
var Js_TcpIpWanHelpMsg="This page is used to configure the parameters for Internet network which connects to the WAN port of your Access Point. Here you may change the access method to static IP, DHCP, PPPoE, PPTP or L2TP  by click the item value of WAN Access type.";
// static dhcp
var Js_EnabeStaticDHCP="Enable Static DHCP";
var Js_StaticDhcpList="Static DHCP List";
// wan settings
var Js_WanInterfaceSetup="WAN Settings";
//var Js_DHCPClient="DHCP Client";
var Js_MTUSize="MTU Size";
var Js_Fppoeinfo="The First pppoe info";
var Js_ServiceName="Service Name";
var Js_ConnectDemand="Connect on Demand";
var Js_AttainServerName="Attain Server By Domain Name";
var Js_AttainServerAddress="Attain Server By Ip Address";
var Js_MPPEEncryption="Request MPPE Encryption";
var Js_MPPCCompression="Request MPPC Compression";
//var Js_DNSMode="DNS Mode";
var Js_AttainAutomatically="Attain AFTR Automatically";
var Js_SetManually="Set AFTR Manually";
var Js_AFTRIPv6Addr="AFTR IPv6 Address";
var Js_WanIPv6Addr="WAN IPv6 Address";
var Js_EnableWebServer="Enable Web Server on Port";
var Js_IPsecPassThrough="IPsec pass through";
var Js_EnableIPsec="Enable IPsec pass through on VPN connection";
var Js_PptpThrough="PPTP pass through";
var Js_EnablePPTPVPN="Enable PPTP pass through on VPN connection";
var Js_L2TPThrough="L2TP pass through";
var Js_EnableL2TPVPN="Enable L2TP pass through on VPN connection";
var Js_IPv6Through="IPv6 pass through";
var Js_EnableIPv6VPNconnect="Enable IPv6 pass through on VPN connection";
var Js_Ethernet802_1x="ethernet 802.1x on WAN";
//var Js_EnabeEth802_1x="Enable ethernet 802.1x on WAN";
//var Js_EAPType="EAP Type";
var Js_EAPTTLSType="EAP TTLS Phase2 Type";
var Js_EAPUserID="EAP User ID";
/**********vpn.htm**********/
var vpn_header='VPN server settings';
var vpn_server="VPN server";
var vpn_mppe='PPTP encryption（MPPE）';
var vpn_ipsec="L2TP encryption（IPSEC）";
var vpn_psk="IPSEC pre-common key";
var vpn_add_header='New rules (up to 6 groups)';
var vpn_protocol="VPN Connection Agreement";
var vpn_user_account="VPN user account";
//var vpn_password="Password";
var vpn_client_ip="Client IP address";
var vpn_connt_pro="Connection protocol";
var vpn_linked="Connection status";
//var vpn_header="VPN server settings";
var vpn_alert1="IPSEC pre-key must be set first";
var vpn_alert2="The same VPN connection mode can only set up to 3 groups";
var vpn_alert3="The same VPN username is existed";
var vpn_alert4="The number of connections is up to 6 groups";
//var vpn_header="VPN server setting";
var vpn_mppe_set="MPPE encryption";
var vpn_ipsec_set="IPSEC encryption";
var vpn_no_epn="Unencrypted";
var vpn_pptp_list="PPTP user list";
var vpn_l2tp_lsit="L2TP user list";
//--------------------------------------

// ipv6 wan setting
//var Js_WanIntfcSetup="WAN Interface Setup";
var Js_EnableIPv6="Enable IPv6";
var Js_OriginType="Origin Type";
var Js_WanLinkType="WAN Link Type";
var Js_ACName="AC Name";
var Js_StaticIPAddr="Static IP Address";
var Js_StatelessAddrAutoCfg="Stateless Address Auto Configuration";
var Js_StatefulAddrAutoCfg="Stateful Address Auto Configuration";
var Js_PDEnable="PD Enable";
var Js_RapidEnable="Rapid-commit Enable";
var Js_Mask="Mask";
var Js_6RDBorderRelayIPv4Addr="6RD Border Relay IPv4 Address";
var Js_EnableMLDProxy="Enable MLD Proxy";
//var Js_IPv4AddrorMask="IPv4 Address / Mask";
// ipv6 lan
var Js_LanAddrInvalid="LAN address invalid!";
var Js_UlaaddrInvalid="ULA address invalid!";
var Js_DNSInvalid=" dns address invalid!";
var Js_StatAddrInvalid=" start address invalid!";
var Js_EndAddrInvalid=" end address invalid!";
var Js_CfgLanSet="Configuring LAN setting";
var Js_IpAddrlen="IP Address / Prefix Length";
var Js_CfgUlaSet="Configuring ULA setting";
var Js_SetUlaManual="Set ULA Manually";
var Js_SetUlaAuto="Set ULA Automatically";
var Js_PrefixLen="Prefix Length";
var Js_CfgDhcp6Server="Configuring DHCPv6 Server";
var Js_AddrsPool="Addrs Pool";
var Js_DnsAddr="DNS Addr";
var Js_InterfaceName="Interface Name";
var Js_AddrPrefix="Addrs Prefix";
var Js_Manually="Manually";
var Js_PreDele="Prefix Delegation";
var Js_ULAprefix="ULA Prefix";
// radvd.htm
var Js_1preaddrinvalid="First prefix address invalid!";
var Js_2preaddrinvalid="Second prefix address invalid!";
var Js_CfgRouter="Configuring Router Advertisement";
var Js_RadvdInfaceName="radvdinterfacename";
var Js_MaxRtInterval="MaxRtrAdvInterval";
var Js_MinRtrInterval="MinRtrAdvInterval";
var Js_MinDelayRas="MinDelayBetweenRAs";
var Js_AdvFlag="AdvManagedFlag";
var Js_AdvOtherCfgFg="AdvOtherConfigFlag";
var Js_AdvLinkMtu="AdvLinkMTU";
var Js_AdvReaTime="AdvReachableTime";
var Js_AdvRetransTimer="AdvRetransTimer";
var Js_AdvCurHopLimit="AdvCurHopLimit";
var Js_AdvDefLifeTime="AdvDefaultLifetime";
var Js_AdvDefPreference="AdvDefaultPreference";
var Js_AdvSrcLLAddr="AdvSourceLLAddress";
var Js_UNicastOnly="UnicastOnly";
//var Js_ULAPre="ULA Prefix";
var Js_EnPrefix1="Enable Prefix1";
var Js_AdvLinkFlag="Adv On Link Flag";
var Js_AdvAutoFlag="Adv Auto nomous Flag";
var Js_AdvValidLifeTime="Adv Valid Life time";
var Js_AdvPreLifeTime="Adv Preferred Life time";
var Js_AdvRouteAddr="Adv Router Addr";
var Js_If624="if 6to4";
var Js_EnPrefix2="Enable Prefix2";
var Js_Medium="medium";

// tunne6l.htm

var Js_CfgTunnel="Configuring Tunnel(6to4)";
var Js_PortFilter="Port Filtering";
var Js_EnablePortFilter="Enable Port Filtering";
var Js_PortRange="Port Range";

//ipv6 Status

var ipv6_header="IPv6 Status";
var ipv6_WanCfg="WAN Configuration";
var ipv6_ConntType="Connection Type";
var ipv6_Addr="IPv6 Address";
var ipv6_DefaultGw="IPv6 Default Gateway";
var ipv6_MainDns="DNS1";
var ipv6_MinDns="DNS2";
var ipv6_LanCfg="LAN Configuration";
var ipv6_AddrType="IPv6 Address Assign Type";
var ipv6_LinkAddr="Link-local Address";
var ipv6_StaticIp="Static IP Connected";
var ipv6_NoStaticIp="Static IP Disconnected";
var ipv6_PPPoeConnt="PPPoE Connected";
var ipv6_PPPoeNoConnt="PPPoE Disconnected";
var ipv6_DynamicIp="Dynamic IP";
//var ipv6_NoDynamicIp="Dynamic IP Disconnected";
//ipv6 Setup
var ipv6_Setup="IPv6 Setup";
var ipv6_Internet="Internet";
var ipv6_InterConType="Internet Connection Type";
var ipv6_Apply="Apply";
var ipv6_DefutGw="Default Gateway";
var ipv6_MTU="MTU(bytes)";
var ipv6_PrefixType="Site Prefix Type";
var ipv6_AddrType="Address Type";
var ipv6_PrefixAddr="Address Prefix";
var ipv6_UserName="User Name";
var ipv6_Password="Password";
var ipv6_ConfirmPasswd="Confirm Password";
var ipv6_DnsAddr="DNS Address";
var ipv6_GetISP="Get Dynamically from ISP";
var ipv6_UseDnsAddr="Use the following DNS Address";
var ipv6_Renew="Renew";
var ipv6_SubnetMask="Subnet Mask";
var ipv6_Release="Release";
var ipv6_IPv6LAN="IPv6 LAN";
var ipv6_Address_Pool_Start="Address Pool Start";
var ipv6_Address_Pool_End="Address Pool End";
var Js_Username_Empty="UserName is empty, please re-enter.";
var Js_Password_Empty="Password is empty, please re-enter.";
var Js_Confirm_Empty="Confirm is empty, please re-enter.";
var Js_Password_unmatch="Password input is inconsistent, please re_enter.";
var Js_Dns1_Empty="DNS1 is empty, please re-enter.";
var Js_Address_Empty="IPV6 Addreess is empty, please re-enter.";
var Js_DefaultGw_Empty="Defalut Gateway is empty, please re-enter.";
var Js_conn="Connected";
var Js_ipv6_disconn="Disconnected";
var ipv6_LanSet="IPv6 LAN Setup";



/***********	vlan.htm ************/
var iptv_header = 'IPTV Settings';
var vlan_header = 'IPTV Settings';
var vlan_header_explain = 'Entries in below table are used to config vlan settings.VLANs are created to provide the segmentation services traditionally provided by routers. VLANs address issues such as scalability, security, and network management.';
var vlan_apply = 'Apply';
var vlan_reset = 'Reset';
var vlan_enable = 'Enabled';
var vlan_disable = 'Disabled';
var vlan_triple_play = 'Triple Play / IPTV';
var vlan_id = 'VLAN ID';
var vlan_tagtbl = 'Tag Table';
var vlan_tagtbl_interface = 'Interface Name';
var vlan_tagtbl_taged = 'Taged';
var vlan_tagtbl_untaged = 'Untaged';
var vlan_tagtbl_notin = 'Not in this VLAN';
var vlan_settbl = 'Current VLAN Setting Table';
var vlan_settbl_id = 'VLAN ID';
var vlan_and=" and ";
var vlan_InternalUse=" are for internal use!";
var vlan_settbl_taged = 'Taged Interface';
var vlan_settbl_untaged = 'Untaged Interface';
var vlan_settbl_modify = 'Modify';
var vlan_settbl_select = 'Select';
var vlan_deletechick = 'Delete Selected';
var vlan_deleteall = 'Delete All';
var vlan_nettbl = 'Current net interface setting table';
var vlan_nettbl_name = 'Interface Name';
var vlan_nettbl_pvid = 'PVID';
var vlan_nettbl_defprio = 'Default Priority';
var vlan_nettbl_defcfi = 'Default CFI';
var vlan_checkadd1 = 'Invalid VLAN ID. Must between 2-4094';
var vlan_checkadd2 = 'At least one interface should bind to this VLAN!!';
var vlan_checkadd3 = "Invalid VLAN ID. It should be in number (0-9).";
var vlan_deletesel = 'Do you really want to delete the selected entry?';
var vlan_deleteall_conf = 'Do you really want to delete all entries?';
var vlan_DiffIdNotSame="Different vlan group's id should not be the same!";
var vlan_OnlyUntag="only one Bridge group can be untagged!";
var vlan_NoPortIncluded="WAN and at least one LAN/WLAN port should be included!";
var valn_Only1untagBridgeWan="Only support 1 untagged bridge-wan at most!";
var vlan_tbl_enable ='Enable';
var vlan_tbl_eth_wire ='Ethernet/Wireless';
var vlan_tbl_forwarding_rule='Forwarding Rule';
var vlan_tbl_wan_lan = 'WAN/LAN';
var vlan_tbl_tag = 'Tag';
var vlan_tbl_priority = 'Priority';
var vlan_tbl_cfi = 'CFI';
var vlan_tbl_vid ='VID';
var vlan_tbl_information = 'VLAN Information';
var vlan_tbl_port_map ='Port Mapping (LAN&nbsp;&amp;&nbsp;  WLAN)<br>&nbsp;P1&nbsp;P2&nbsp;P3&nbsp;P4&nbsp;W1&nbsp;W2&nbsp;W3&nbsp;';
var vlan_eth_port="Ethernet port";
var vlan_Wlan2GPrimary="Wireless 2.4GHZ Primary AP";
var vlan_Wlan5GPrimary="Wireless 5GHZ Primary AP";
var vlan_Wlan2GVap="Wireless 2.4GHZ Virtual AP";
var vlan_Wlan5GVap="Wireless 5GHZ Virtual AP";
var reboot_confirm="Do you really want to reboot this router?";
/*********   ip6filter.htm   *********/
var Js_IpfilterHelpMsg=" Entries in this table are used to restrict certain types of data packets from your local network to Internet through the Gateway.  Use of such filters can be helpful in securing or restricting your local network.";
var Js_IPFilter="IP Filtering";
var Js_LocalAddr="Local IPv4 Address";
var Js_LocaAddripv6="Local IPv6 Address";
var Js_FilterTab="Current Filter Table";

var ipfilter_header = 'IP/Port Filtering';
var ipfilter_header_explain = ' Entries in this table are used to restrict certain types of data packets from your local network to Internet through the Gateway.  Use of such filters can be helpful in securing or restricting your local network.';
var ipfilter_enable = 'IP/Port Filtering';


// MAC Filtering
var Js_MACFilter="MAC Filtering";
var Js_LocalIPAddr="Local IP Address";
var Js_LocalPortRange="Local Port Range";
var Js_RemoteIPAddr="Remote IP Address";
var Js_RemotePortRange="Remote Port Range";
var Js_CurrentPortForwardTable="Current Port Forwarding Table";
// portfw.htm
var Js_PortForward="Virtual Server";
var Js_PortfwHelpMsg="Virtual Servers are used to set up public services on your local network. A virtual server is defined as an external port, and all requests from the internet to this external port will be redirected to a designated computer, which must be configured with a static or reserved IP address."
var Js_PortfwAdd="Add";
var Js_PortfwDel="Del";
var Js_PortfwServiceName="Service Type";
var Js_PortfwExternalPort="External Port";
var Js_PortfwInternalPort="Internal Port";
var Js_PortfwInternalServer="Internal server IP";
var Js_PortfwProtocol="Protocol";
var Js_PortfwStatus="Status";
var Js_PortfwModify="Modify";
var Js_PortfwViewBtn="View Existing Services";
var Js_PortfwCancel="Cancel";
var Js_PortfwApply="Apply";
var Js_PortfwExistSer="Existing Services";
var Js_PortfwMsg1="Can not be empty.";
var Js_PortfwMsg2="Invalid format.";
var Js_PortfwMsg3="Invalid format, Please enter a value of 1-65535.";
var Js_PortfwMsg4="This Item conflicts with existed items.";
var Js_PortfwMsg5="Invalid format, Please enter a value of 2-253.";
var Js_PortfwMsg6="Internal Server IP cannot be the same with the LAN IP address.";
var Js_PortfwMsg7="The maximum number of rules is 32.";
//url filtering
var Js_UrlFiltering="URL Filtering";
var Js_UrlAddr="URL Address";
var Js_DenyUrlAddr="deny url address(black list)";
var Js_AllowUrlAddr="allow url address(white list)";
var Js_UserMode="User mode";
var Js_AllUser="All users (default rule)";
var Js_UrlFltHelpMsg="URL filter is used to deny LAN users from accessing the internet. Block those URLs which contain keywords listed below.";
// dmz
// vlan
var Js_HardwareNat="Hardware NAT";
var Js_CurrentVLANTable="Current VLAN Table";
//var Js_ForwardRule="Forwarding Rule";
var Js_TaggedPort="Tagged Ports";
var Js_UnTaggedPort="Untagged Ports";
var Js_ChangePVID="Change PVID Setting";
var Js_DmzHelpMsg="A Demilitarized Zone is used to provide Internet services without sacrificing unauthorized access to its local private network. Typically, the DMZ host contains devices accessible to Internet traffic, such as Web (HTTP ) servers, FTP servers, SMTP (e-mail) servers and DNS servers."
//route 
var Js_RoutSetup="Routing Setup";
var Js_EnableStaticRoute="Enable Static Route";
var Js_EnableDynamicRoute="Enable Dynamic Route";
var Js_RouteNat="NAT:";
var Js_RouteRipS="RIP Send:";
var Js_RouteRipR="RIP Recv:";

var Js_ArpTable_Clients="DHCP Clients & ARP Table";
var Js_ArpTable="ARP Table";
var Js_DhcpClients_Table="DHCP Clients Table";

var Js_StaticRouteTable="Static Route Table";
var Js_RoutingTable="Routing Table";
var Js_ShowAllEntries="This table shows all the RIPng routing entries";
var Js_NextHop="Next Hop";
var Js_VlanFlag="Flags";
var Js_VlanRef="Ref";
var Js_VlanUse="Use";
var Js_VlanIface="Iface";
var Js_RouteDes="Destination";
var Js_RouteGw="Gateway";
var Js_RouteGenmask="Genmask";
var Js_RouteMetric="Metric";
var Js_RouteInterface="Interface";
var Js_Routetype="Type";
var Js_RouteDynamic="Dynamic";
var Js_RouteStatic="Static";
var Js_RouteRef="Ref";
var Js_RouteIface="Iface";

var Js_StaticRouteDes="Destination IP Address";
var Js_StaticRouteNetMask="Netmask";
 
// qos
var Js_Wrongip6addrlen="Wrong ipv6 address length!";
var Js_Ipaddrinvalid=" IP address invalid!"
var Js_InvalidPort="invalid port!";
var Js_UplinkPhyportInvalid="uplink phyport invalid!";
var Js_DownlinkPhyportInvalid="downlink phyport invalid!";
var Js_InvalidNum="invalid number!";
var Js_AutoUplinkSpeed="Automatic Uplink Speed";
var Js_ManualUplinkSpeed="Manual Uplink Speed";
var Js_AutoDownlinkSpeed="Automatic Downlink Speed";
var Js_ManualDownLinkSpeed="Manual Downlink Speed";
var Js_LocalPort="Local Port";
var Js_RemotIpAddr="Remot IP Address";
var Js_RemotePort="Remote Port";
var Js_RemoteMacAddr="remote MAC Address";
var Js_PhyPort="phyport";
var Js_GuaranteedMinimumBandwidth="Guaranteed minimum bandwidth";
var Js_RestrictedMaximumBandwidth="Restricted maximum bandwidth";
var Js_UplinkBandwidth="Uplink Bandwidth";
var Js_DownlinkBandwidth="Downlink Bandwidth";
var Js_Policy="Policy";
var Js_priority="priority";
var Js_weight="weight";
var Js_remark="remark";
var Js_Layer="Layer";
var Js_CurrQosTable="Current QoS Rules Table";
var Js_QosHelpMsg=" Entries in this table improve your online gaming experience by ensuring that your game traffic is prioritized over other network traffic, such as FTP or Web.";
var Js_Qoserr1="can't set qos rule without bandwith!";
var Js_Qoserr2="can't set qos rule with nothing!";
var Js_Qoserr3="local ip conflict!";
var Js_Qoserr4="Error: for guaranteed minimum bandwidth of both uplink and downlink, the sum bandwidth of all qos rules are larger than the total bandwidth!";
var Js_Qoserr5="Error: for guaranteed minimum bandwidth of downlink, the sum bandwidth of all qos rules is larger than the total downlink bandwidth!";
var Js_Qoserr6="Error: for guaranteed minimum bandwidth of uplink, the sum bandwidth of all qos rules is larger than the total uplink bandwidth!";
var Js_Qoserr7="Error: for guaranteed maximum bandwidth of downlink, the bandwidth is larger than the total downlink bandwidth!";
var Js_Qoserr8="Error: for guaranteed maximum bandwidth of uplink, the bandwidth is larger than the total uplink bandwidth!";
var Js_Qoserr9="mac address conflict!";
var Js_Qoserr10="mannual uplink exceed max range!";
var Js_Qoserr11="mannual downlink exceed max range!";
//dns
var Js_DDNSSeting="DDNS Settings";
var Js_ServiceProvider="Service Provider";
var Js_DdnsHelpMsg="Dynamic DNS is a service, that provides you with a valid, unchanging, internet domain name (an URL) to go with that (possibly everchanging) IP-address";
var ddns_upt_interval = "Auto-Update Interval";
var ddns_user_name = ' User Name/Email';
var ddns_passwd = ' Password/Key';
var ddns_time= 'Min';
var ddns_status='DDNS Status';
var ddns_domain_ip='Domain IP';
var ddns_status_success='DDNS Update Successfully';
var ddns_status_false='Authentication Failed';
//ntp.html
var Js_Invalid="Invalid ";
var Js_TimeZoneSetting="Time Zone Settings";
var Js_TimeZone_header="Time Zone Setting";
var Js_CurrentTime="Current Time";
var Js_Timetype="Time Set Type";
var Js_EnableNTPclientupdate="Enable NTP client update";
var Js_TimeZoneSelect="Time Zone Select:";
var Js_AutoDaylightSave="Automatically Adjust Daylight Saving";
var Js_ManualIPSetting="Manual IP Setting";
var Js_NtpHelpMsg="You can maintain the system time by synchronizing with a public time server over the Internet.";
var Js_NtpServer1="NTP Server 1";
var Js_NtpServer2="NTP Server 2";
var Js_UpdateNow="Update now";
var Js_GetTime_FromInternet="Get time automatically form internet";
var Js_ManuSetting="Manual Setting";
var Js_Example="(ex:";
var Js_Optional="(Optional)";
var Js_AutoSync="Automatically synchronize NTP time";
var Js_NtpSyncSuccess="The clock was successfully synchronized with";
//dos
var Js_DosHelpMsg='A "denial-of-service" (DoS) attack is characterized by an explicit attempt by hackers to prevent legitimate users of a service from using that service.';
var Js_Dns="Denial of Service";
var Js_enDns="Enable DoS Prevention";
var Js_WholeSysFlood="Whole System Flood";
var Js_packSec="Packets/Second";
var Js_PreIpFlood="Per-Source IP Flood SYN";
var Js_PortScan="TCP/UDP Port Scan";
var Js_BlockTime="Block time (sec)";
//tr069
var Js_TRCfg="TR-069 Configuration";
var Js_PeriodicInform="Periodic Inform ";
var Js_ConReq="Connection Request";
var Js_ServerURL="Server URL";
var Js_CerMangment="Certificat Management";
var Js_Certificat="Certificat";
var Js_Choosefile="Choose file ...";
var Js_Upload="Upload";
var Js_Tr069HelpMsg=" On this page you can configure the TR-069 CPE. Here you can change the setting of ACS.";
var Js_Tr069ChgSuccess="Change setting successfully!";
//login.htm
var Js_UserLog="USER LOGIN";
var Js_ForgetPasswd="Forget Password?";
var lgps1="New Login Password";//設定登入密碼
var lgps2="Skip";//略過
var lgps3="New Password";//新密碼
var lgps4="Confirm Password";//確認密碼
var lgps5="Length range is 6-15";//長度範圍6-15個字元
var lgps6="Set Up";//確定
var lgps7="Note: Set a new login password to prevent the router from being compromised";//注意:為了提高路由器的安全性,建議您設定一組新的登入密碼。
var lgps8="Verification Code(No Case sensitive)";//驗證碼(區分大小寫)
var lgps9="Login";//登入
var lgerr1="Cannot be empty";//密碼不可為空白
var lgerr2="length range is 6-15";//密碼長度必須介於6-15個字元
var lgerr3="Password only allows numbers and letters";//密碼必須為數字或英文字母
var lgerr4="Inconsistent with new password";//兩次密碼輸入不一致
var lgerr5="User Name cannot be empty";//使用者名稱不可為空白
var lgerr6="User Name is error";//使用者名稱錯誤
var lgerr7="Password cannot be empty";//密碼不可為空白
var lgerr8="Password is error";//密碼錯誤
var lgerr9="Verification Code is error";//驗證碼錯誤
var lgerr10="Input error three times, please wait 2 minutes to try again";//登入三次失敗,請稍待2分鐘後再次嘗試登入。
var lgerr11="ERROR: Password has been updated, <a href=\"login.htm\" style=\"color:#0095c5;font-weight:bold;\">Please login</a>.";
var lgerr12="The registration code has expired, please enter again.";
var lgerr13="Users have logged in from other browsers on this device. You can't log in with different browsers at the same time. Please try again later or login through the browser you used last time.";
var lgerr14="User is logined from";
var lgerr15="You can't login on different devices at the same time. Please try again later or login through the device and browser you used last time.";
//title2.htm 
var Js_AdvSet="Advanced Setup";
////////////logout.htm/////////////////////////////////
var logout_is='Do you want to logout ?';
var logout_apply = 'Apply';
/*************    menu.htm    *************/
var menu_system_status='Status';
var menu_opmode ='Operation Mode';
var menu_tcpip_2nd = 'For IP Routing';
var menu_tcpip='Network';
var menu_wan='WAN Settings'; 
var menu_lan='LAN Settings';
var menu_schedule='Wireless Schedule';
var menu_rootap="Basic Settings";
var menu_vap="Multiple SSID";
var menu_client="Wireless Repeater";
var menu_advance='Advanced Settings';
var menu_accessControl='Access Control';
var menu_siteSurvey='Site Survey';
var menu_wds='WDS Settings';
var menu_wps='WPS Settings';
var menu_ipv6="IPv6 Network";
var menu_ipv6_wan='IPv6  WAN  Setting';
var menu_ipv6_lan='IPv6  LAN  Setting';
var menu_radvd = "RADVD for IPv6"; 
var menu_tunnel6 = "IPv6 Tunnel to IPv4";
var menu_wireless='Wireless';
var menu_qos='QoS';
var menu_fireWall='Firewall';
var menu_portFilter='Port Filtering';
var menu_ipFilter='IP/Port Filtering';
var menu_macFilter='MAC Filtering';
var menu_portFw='Port Forwarding';
var menu_urlFilter='URL Filtering';
var menu_dmz='DMZ';
var menu_vlan='IPTV Settings';
var menu_management='System';
var menu_updateFm='Upgrade Firmware';
var menu_settings='Save/Reload Settings';
var menu_timeZone='Time Zone Settings';
var menu_ddns='DDNS Settings';
var menu_dos='Denial-of-Service';
var menu_tr069="TR-069 Config";
var menu_pwd='Password Settings';
var menu_sysCmd ='Run Command';
var menu_logout='Logout';
var menu_log='System Log';
var menu_staticRoute='Static Route';
var menu_routeTbl = 'Routing Table';
var menu_diagnosis= 'Diagonsis';
var menu_routeTracking= 'Route Tracking';

//syscmd_ping 
var Ping_Address = 'Ping Address';
var Ping_Number  = 'Ping Number';
var syscmd_ping = 'This page is used for Ping diagnosis.'
var Ping_msg1 = 'Ping address cannot be empty.';
var Ping_msg2 = 'Please enter the correct domain name or IP address.';
var Ping_msg3 = 'The ping number cannot be empty.';
var Ping_msg4 =  'please input the number of ping.';
var Ping_msg5 =  'The range of the number of Ping is: 1~60.';
var Ping_msg6 = 'Please enter the Ping address.';
var Ping_msg7 = 'Please enter the number of Ping.';
//syscmd_tracert 
var Trace_Address = 'Trace Address';
var Track_Number  = 'Track Number';
var syscmd_tracert= 'This page is used for route tracking. Enter the route tracking command and click [Execute] to implement route tracking.';
var tracert_msg1 = 'The route track address cannot be empty.';
var tracert_msg2 = 'Please enter the correct domain name or IP address.';
var tracert_msg3 = 'The route track number cannot be empty.';
var tracert_msg4 =  'Please enter the number of route traces.';
var tracert_msg5 =  'The range of tracking numbers is: 1~60.';
var tracert_msg6 = 'Please enter the domain name or IP address.';
var tracert_msg7 = 'Please enter the number of route traces.';
//syscmd_telnet
var syscmd_telnet='This page is used for Open Telnet.';
//system log
var Js_SysLog="System Log";
var Js_EnabeLog="Enable Log";
var Js_systemAll="system all";
var Js_LogServerIpAddr="Log Server IP Address";
var Js_EnableRemoteLog=" Enable Remote Log";
var Js_SystemHelpMsg="This page can be used to set remote log server and show the system log.";
//upload.htm
var Js_UpFirmware="Upgrade Firmware";
var Js_UpFirmareVersion="Firmware Version";
var Js_Upgrade = 'Upgrade';
var Js_NofileSelect="no file selected";
var Js_SelNewFireware="Select New Firmware";
var Js_UpLoadHelpMsg="This page allows you upgrade the Access Point firmware to new version. Please note, do not power off the device during the upload because it may crash the system.";
//Remote Upgrade rfw.htm
var Js_RemoteUpgrade="Upgrade Online";
var Js_CheckNew="Check New";
var Js_Upgrade="Upgrade";
var Js_LoadNewFireware="Loading New Firmware";
var Js_NoNewer_firmware="No newer firmware";
//saveconfig.htm
var js_SaveCfgHelpMsg="This page allows you save current settings to a file or reload the settings from the file which was saved previously. Besides, you could reset the current configuration to factory default.";
var Js_SaveSetting="Save/Reload Settings";
var Js_Save2File="Save Settings to File";
var Js_Save="Save...";
var Js_SetingFrmFile="Load Settings from File";
var Js_NoFileSelect="no file selected";
var Js_ResetsettingtoDef="Reset Settings to Default";
var Js_InvalidFile="Invalid configuration file!";
var Js_InvalidFormat="Invalid file format.";
var Js_RestoreValue="Load Settings from File";

//password setup
var Js_PasswordSetup="Password Setup";
var Js_NewPassword="New Password";
var Js_ConfirmedPassword="Confirmed Password";
var Js_CurrentUserName="Current User Name";
var Js_CurrentPassword="Current Password";
var password_name_error = "Current User Name is wrong!";
var password_passwd_error = "Current Password is wrong!";
var Js_PwHelpMsg="This page is used to set the account to access the web server of Access Point. Empty user name and password will disable the protection.";
/***********   syscmd.htm   ***********/
var syscmd_header = 'System Command';
var syscmd_explain = 'This page can be used to run target system command.';
var syscmd_command = 'System Command';
var syscmd_apply = 'Apply';
var syscmd_refresh = 'Refresh';
var syscmd_alert1 = 'Please add "-c num" to ping command';
var syscmd_alert2 = 'Command can not be empty';
/******* countDownPage.htm *******/
var cdp_sr='System is rebooting';
var cdp_ss='Setting successfully!';
var cdp_pw='Please wait ';
var cdp_sec='Seconds...';

var cdp_note='Note';
var cdp_message='To avoid IP conflicts with the front-end router,the IP of the router is changing';
var cdp_wait='Wait time ';
var cdp_ipChange='your router IP adress has been changed to ';


//+++++++++++==Button++++++++++++
var BT_Reset="Reset";
var BT_ApplyChange="Apply Changes";
var BT_Save="Save";
var BT_SaveApply="Apply";
var BT_DelSelect="Delete Select";
var BT_DelAll="Delete All";
var BT_ShowStat="Show Statistics";
var BT_Connect="Connect";
var BT_Disconnect="Disconnect";
var BT_Apply="Apply";
var BT_SelectALL="Select ALL";
var BT_ClearALL="Clear ALL";
var BT_Clear="Clear";
var BT_Default="default";
var BT_ShowClient="Show Clients";
var BT_Close="Close";
var BT_Easy="Easy Setup";
var BT_Advanced = "Advanced Setup";
var BT_Help="Help";
var BT_Reboot="Reboot";
var BT_Next="Next";
var BT_Scan="Scan";
var BT_Connect="Connect";
var BT_Back="Back";


var wladv_limit_client_ap = 'Limit Client AP(1-32)';
var wladv_limit_client_ap1 = 'Limit Client AP1(1-32)';
var wladv_limit_client_ap2 = 'Limit Client AP2(1-32)';
var wladv_limit_client_ap3 = 'Limit Client AP3(1-32)';
var wladv_limit_client_ap4 = 'Limit Client AP4(1-32)';

var wladv_limit_client_ap_more = 'Limit Client AP(3-64)';
var wladv_limit_client_ap_more2 = 'Limit Client AP(1-64)';



var MM_SendPack="Sent Packets";
var MM_RcvPack="Received Packets";
var MM_LAN="Ethernet LAN";
var MM_LAN1="Ethernet LAN1";
var MM_LAN2="Ethernet LAN2";
var MM_LAN3="Ethernet LAN3";
var MM_LAN4="Ethernet LAN4";
var MM_LAN5="Ethernet LAN5";
var MM_WAN="Ethernet WAN";
var MM_Refresh="Refresh";
var MM_Clear="Clear";
var MM_Internet="Internet";
var wizard_state="Connect Status";
var MM_Status="Status";
var MM_ConnectionType="WAN Access Type";
var MM_Static="Static";
var MM_Client="Client";
var MM_Cable=" Client";
var MM_Ip="IP Address";
var MM_DhcpServer="DHCP Server";
var MM_Mask="Subnet Mask";
var MM_Gateway="Default Gateway";
var MM_ServerIp="Server IP address";
var MM_StaticIp="Static IP";
var MM_DnsAuto="Attain DNS Automatically";
var MM_DnsManual="Set DNS Manually";
var Js_NetMaskErrorFir="Invalid subnet mask in 1st digit.\nIt should be the number of 128, 192, 224, 240, 248, 252 or 254";
var Js_NetMaskErrorSec="Invalid subnet mask in 2nd digit.\nIt should be the number of 0, 128, 192, 224, 240, 248, 252 or 254";
var Js_NetMaskErrorThi="Invalid subnet mask in 3rd digit.\nIt should be the number of 0, 128, 192, 224, 240, 248, 252 or 254";
var Js_NetMaskErrorFor="Invalid subnet mask in 4th digit.\nIt should be the number of 0, 128, 192, 224, 240, 248, 252 or 254";
var Js_NetMaskError="Invalid subnet mask value. It should be the decimal number (0-9).";
var Js_IPAddrError="Invalid IP address value! Invalid value. It should be the decimal number (0-9).";
var Js_CannotAddNew="Cannot add new entry because the ip is not the same subnet as LAN network!";
var Js_IPAddrError1="Invalid ip address! It must be in the lan dhcp server ip range, and is not same with router's ip!";
var Js_LanDhcpError2="DHCP Client Range can't cover Static DHCP List!!!";
//var MM_Lan="LAN TCPIP";
var MM_WirelessNetwork="Wireless Network";
var MM_Wireless="Wireless";
var MM_Wireless1="Wireless";
var MM_MacAddr="MAC Address";
var MM_DNSServe="DNS server";
var MM_Encrypt="Encrypt";
var MM_Encryption="Encryption";
var MM_WireLessClient="Wireless Client";
var MM_Disabled="Disabled";
var MM_disable="disable";
var MM_Auto="Auto";
var MM_OnOff="Multiple SSID ";
var MM_BasicSetting="Basic Settings";
var MM_SharedKey="Shared Key";
var MM_KeyFormat="Key Format";
var MM_AuthMode="Authentication Mode";
var MM_None="None";
var MM_Capable="capable";
var MM_Required="required";
var MM_Passphrase="Passphrase";
var MM_Server="Server";
var MM_Address="Address";
var MM_Port="Port";
var MM_Band="Band";
var MM_Mode="Mode";
var MM_ModeStatus="Mode";
var MM_Member="Member";
var MM_Tagged="Tagged";
var MM_NetType="Network Type";
var MM_Infrastrct="Infrastructure";
var MM_band_width="Channel Width";
var MM_SideBand="Control Sideband";
var MM_ChannelNum="Channel Number";
var MM_BSsid="Broadcast SSID";
var MM_DataRate="Data Rate";
var MM_CloneMac="Clone MAC";
var MM_Fragment="Fragment Threshold";
var MM_Rts="RTS Threshold";
var MM_Beacon="Beacon Interval";
var MM_TxPreamble="Preamble Type";
var MM_LongTxPreamble="Long Preamble";
var MM_ShortTxPreamble="Short Preamble";
var MM_Channel="Channel";
var MM_day="Days";
var MM_From="From";
var MM_To="To";
var MM_Enable="Enable";
var MM_Enabled="Enabled";
var MM_Disable="Disable";
var MM_Disabled="Disabled";
var MM_On="On";
var MM_Off="Off";
var MM_Comment="Comment";
var MM_WdsTbl="Current WDS AP List";
var MM_Configured="Configured";
var MM_UnConfigured="UnConfigured"
var MM_Locked="locked";
var MM_UnLocked="unlocked";
var MM_Configuration="Configuration";
var MM_Stop="STOP";
var MM_Key="Key";
var MM_Repeater="Repeater";
var MM_VirtualClient="Virtual Client";
var MM_VirtualAP="Virtual AP";
var MM_Week7="Sun";
var MM_Week1="Mon";
var MM_Week2="Tue";
var MM_Week3="Wed";
var MM_Week4="Thu";
var MM_Week5="Fri";
var MM_Week6="Sat"
var MM_Everyday="Everyday";
var MM_DhcpList="DHCP Client Range";
var MM_DhcpTime="DHCP Lease Time";
var MM_minutes="minutes";
var MM_DomainName="Domain Name";
var MM_DhcpClientsList="DHCP Clients List";
var MM_dhcp = "Dynamic IP";
var MM_StaticDhcpSetup="Static DHCP Setup";
var MM_PortNumb="Port Number";
var MM_HostName="Host Name";
var MM_WanConnectionType="Wan Type";
var MM_Continuous="Continuous";
var MM_Manual="Manual";
var MM_IdleTime="Idle Time";
var MM_bytes="bytes";
var MM_Wan_ping="Ping Access on WAN";
var MM_Ethernet="Ethernet";
var MM_Others="Others";
var MM_Protocol="Protocol";
var MM_Both="TCP+UDP";
var MM_All="All";
var MM_IpAddr="Ip Address";
var MM_DhcpConnect="DHCP Connected";
var tcpip_wan_web_server_port = 'Web Server Port';
var default_web_server_port = "(default 8080)";
var tcpip_wan_enable_webserver = 'Enable Web Server Access on WAN';
var tcpip_wan_enable_netsniper='Enable NetSniper';
var tcpip_wan_enable_igmp_snooping = 'Enable IGMP Snooping';
var MM_Open="On";

var tcpip_lan_staicdhcp = 'Static DHCP';
var tcpip_staticdhcp = "Set Static DHCP";
var tcpip_lan_dns_lan_side='LAN-side router IP';
var tcpip_lan_dns_wan_side='Actual WAN DNS';
var tcpip_lan_dns_manual='DNS Manually';
var dhcp_hostname = 'Host Name';
var tcpip_show_client = 'DHCP&ARP Tables';


//var MM_MacAddr="Mac Address";
var MM_UrlFiltering_table="Current URL Filtering List";
var MM_HostIp="Host IP Address";
var MM_ForwardRule="Forwarding Rule";
var MM_Bridge="Bridge";
var MM_Select="Select";
var MM_Default="Default";
var MM_Metric="Metric";
var MM_Interface="Interface";
var MM_Destination="Destination";
var MM_Low="Low";
var MM_High="High";
var MM_Sensitivity="Sensitivity";
var MM_EnSourIpBlock="Enable Source IP Blocking";
var MM_Interval="Interval";
var MM_Path="Path";
var MM_Connection="Connection";
var MM_wireless="wireless";
var MM_Type="Type";
var MM_Name="Name";
var MM_PassWord="Password";
var MM_UserName = "User Name";
var MM_Start="Start";
var MM_NetworkName="NetworkName";
var MM_Schedule="Schedule";
var MM_HELP="Help";
var MM_English="English";
var MM_TChinese="繁體";
var MM_SChinese="中文";
var MM_LanguageRu="Русский язык";
var MM_LanguageVn="Tiếng Việt";
var MM_LanguageUa="Українська";
var MM_Mode="Mode";
var MM_Ssid="Network Name(SSID)";
var MM_EncrypType="Encryp Type";
var tcpip_wan_dhcp_type="WAN DHCP Type";
var tcpip_wan_normal_dhcp="Dynamic IP (DHCP)";
var tcpip_wan_normal_pppoe="Normal PPPoE";
var tcpip_wan_type_pppoe = "PPPoE/Dual WAN Access PPPoE";
var tcpip_wan_type_pptp = "PPTP/Dual WAN Access PPTP";
var tcpip_wan_type_l2tp = "L2TP/Dual WAN Access L2TP"; 
var tcpip_wan_type_usb3g = "USB3G/Dual WAN Access USB3G";
var route_showtbl = 'Show Route Table';	
//var select_dis='停用';
//var select_enb='啟用';

/**********firewall.htm**********/
//var firewall_apply = '確定';
//var firewall_delete_select = '刪除選項';
//var firewall_delete_all = '删除全部';
//var firewall_comm = '描述';
//var firewall_tbl_comm = '描述';
//var firewall_tbl_select = '選擇';

//var firewall_ipaddr_invalid = 'IP位址錯誤';


var MSG_OperationMode="This page is used to change Operation Mode.";
var Js_msg1="Invalid IP address!";
var Js_msg2="IP address cannot be empty! It should be filled with 4 digit numbers as xxx.xxx.xxx.xxx.";
var Js_msg3="Invalid value. It should be the decimal number (0-9).";
var Js_msg4=" range in 1st digit. It should be 1-223.";
var Js_msg5=" range in 1st digit. It should not be 127.";
var Js_msg6=" range in 2nd digit. It should be 0-255.";
var Js_msg7=" range in 3rd digit. It should be 0-255.";
var Js_msg8=" range in 4th digit. It should be 1-254.";
var Js_msg9="Error! Your browser must have CSS support !";
var Js_msg10="Note: If you want to change the setting for Mode and SSID, you must go to EasyConfig page to disable EasyConfig first";
var Js_msg11="Do you also want to enable wireless profile?";
var Js_msg12="if ACL allow list turn on ; WPS2.0 will be disabled";
var Js_msg13="mac address invalid!";
var Js_msg14="Input MAC address is not complete. It should be 12 digits in hex.";
var Js_msg15="Delete the all entries will cause all client cannot connect to AP.  Sure?";
var Js_msg16="Do you really want to delete the selected entry?";
//var Js_msg17="Input MAC address is not complete. It should be 12 digits in hex.";
var Js_msg18="Do you really want to delete the all entries?";
var Js_msg19="mac address invalid!";
//var Js_msg20="Do you really want to delete the selected entry?";
//var Js_msg21="Do you really want to delete the all entries?";
var Js_msg22="WPS was disabled automatically because wireless mode setting could not be supported. You need go to Wireless/Basic page to modify settings to enable WPS.";
var Js_msg23="WPS was disabled automatically because Radius Authentication could not be supported. You need go to Wireless/Security page to modify settings to enable WPS";
//var Js_msg24="PIN number was generated. You have to click \'Apply Changes\' button to make change effectively.";
var Js_msg25="Invalid Enrollee PIN length! The device PIN is usually four or eight digits long.";
var Js_msg26="Invalid Enrollee PIN! Enrollee PIN must be numeric digits.";
var Js_msg27="Checksum failed!";
//var Js_msg28="Input MAC address is not complete. It should be 12 digits in hex.";
//var Js_msg29="mac address invalid!";
var Js_msg30="Schedule Rule ";
var Js_msg31=" Error. The start time latter than end time";
//var Js_msg32="Schedule Rule ";
var Js_msg33=" Error. The start time can't be equal to end time";
var Js_msg34="Invalid IP address value!\nIt should not be reserved IP address(127.x.x.x).";
var Js_msg35="Invalid IP address value! ";
var Js_msg36="Invalid DHCP client start address! ";
var Js_msg37="Invalid DHCP client start address!\nIt should be located in the same subnet of current IP address.";
var Js_msg38="Invalid DHCP client End address! ";
var Js_msg39="Invalid DHCP client end address!\nIt should be located in the same subnet of current IP address.";
var Js_msg40="Invalid DHCP client address range!\nEnding address should be greater than starting address.";
var Js_msg41="Invalid gateway address!\nIt should be located in the same subnet of current IP address.";
//var Js_msg42="Input MAC address is not complete. It should be 12 digits in hex.";
var Js_msg43="Invalid MAC address. It should not be ff:ff:ff:ff:ff:ff.";
var Js_msg44="Invalid MAC address. It should not be multicast mac address.";
var Js_msg45="Invalid MAC address. It should be in hex number (0-9 or a-f).";
var Js_msg46="dhcp lease time invalid!";
var Js_msg47="Invalid Domain Name! Length of Domain Name shoule not more than 63";
var Js_msg48="Invalid Domain Name! Please enter characters in A(a)~Z(z) or 0-9 or - without spacing: ";
var Js_msg49="Invalid Domain Name! Domain name should begin with a letter and end with a letter or digit";
var Js_msg50="This page is used to configure the parameters for local area network which connects to the LAN port of your Access Point. Here you may change the setting for IP addresss, subnet mask, DHCP, etc..";
var Js_msg51="Input MAC address or Port number is invalid. The MAC address should be 12 digits in hex and The Port number should be 1~5.";
var Js_msg52="Invalid IP address value! It is the same with lan ip!";
var Js_msg53="Port number cannot be empty! You should set a value between 1-65535.";
var Js_msg54="Invalid port number! It should be the decimal number (0-9).";
var Js_msg55="Invalid port number! You should set a value between 1-65535.";
var Js_msg56="PPTP user name cannot be empty!";
var Js_msg57="PPTP password cannot be empty!";
var Js_msg58="L2TP user name cannot be empty!";
var Js_msg59="L2TP password cannot be empty";
var Js_msg60="PPP user name cannot be empty!";
var Js_msg61="PPP password cannot be empty!";
var Js_msg62="Invalid pptp default gateway IP address!\nIt should be located in the same subnet of local IP address.";
var Js_msg63="This inside type is not supported.";
var Js_msg64="This phase2 type is not supported.";
var Js_msg65="This EAP type is not supported.";
var Js_msg66="Protocol cannot be empty!";
var Js_msg67="The same IP already exists.";
var Js_msg68="Client IP cannot be empty!";
var Js_msg69="User name cannot be empty!";
var Js_msg70="Password cannot be empty!";
var Js_msg71="pppoe username can't be empty";
var Js_msg72="pppoe password can't be empty";
var Js_msg73="Invalid pppoe mtu size!";
var Js_msg74="dns1 address invalid!";
var Js_msg75="6RD prefix address invalid!";
var Js_msg76="6RD prefix len must be a multiple of 8 between 0 and 64!";
var Js_msg77="6RD prefix len must be a multiple of 8 between 0 and 32";
var Js_msg78="6RD BR address invalid";
var Js_msg79="You should set a port range for adding in an entry.";
var Js_msg80=" IPv6 address invalid!";
var Js_msg81="Port range cannot be empty! You should set a value between 1-65535.";
var Js_msg82="externel Port cannot be empty! You should set a value between 1-65535.";
var Js_msg83="Invalid external-port number! It should be the decimal number (0-9).";
var Js_msg84="Invalid port range! 1st port value should be less than 2nd value.";
var Js_msg85="Invalid external-port number! You should set a value between 1-65535.";
var Js_msg86="Invalid external-port range! 1st port value should be less than 2nd value.";
var Js_msg87="Error character: \";\"";
var Js_msg88="Delete the selected VLAN entry?";
var Js_msg89="Delete all the VLAN entries?";
var Js_msg90="Invalid value. It should be in decimal number (0-9).";
var Js_msg91="Invalid Gateway address! ";
var Js_msg92="Invalid metric value! The range of Metric is 1 ~ 15.";
var Js_msg93="You can not disable NAT in PPP wan type!";
var Js_msg94="Manual Uplink Speed cannot be empty or less then 100 when Automatic Uplink Speed is disabled.";
var Js_msg95="Invalid input! It should be the decimal number (0-9).";
var Js_msg96="Manual Downlink Speed cannot be empty or less then 100 when Automatic Downlink Speed is disabled.";
var Js_msg97="Invalid IP address range!\nEnding address should be greater than starting address.";
var Js_msg98="Invalid start IP address! It should be set within the current subnet.";
var Js_msg99="Invalid end IP address! It should be set within the current subnet.";
var Js_msg101="Domain Name can't be empty";
var Js_msg102="User Name/Email can't be empty";
var Js_msg103="Password  can't be empty";
var Js_msg104="Invalid Number. It should be in  number (0-9).";
var Js_msg105="Invalid month Number. It should be in  number (1-9).";
var Js_msg106="Invalid Time value!";
var Js_msg107="Invalid NTP Server IP address! It can not be empty.";
var Js_msg108="please select a file!";
var Js_msg109="ACS URL cannot be empty!";
var Js_msg110="Invalid User Name !";
var Js_msg111="Invalid Password !";
var Js_msg112="Please input periodic interval time.";
var Js_msg113="Interval should be the decimal number (0-9).";
var Js_msg114="Invalid Path !";
var Js_msg115="Please input the port number for connection request.";
var Js_msg116="Invalid port number of connection request. It should be 0-65535.(0 means default STUN port 3478)";
var Js_msg117="Invalid port number of connection request. It should be 1-65535.(0 means default STUN port 3478)";
var Js_msg118="STUN Server URL cannot be empty!";
var Js_msg119="Please input the port number for STUN Server.";
var Js_msg120="Invalid port number of STUN Server. It should be 0-65535.";
var Js_msg121="Invalid Server address! ";
var Js_msg122="Update firmware failed!";
var Js_msg123="File name can not be empty !";
var Js_msg124="Do you really want to reset the current settings to default?";
var Js_msg125="User account is empty.\nDo you want to disable the password protection?";
var Js_msg126="Password is not matched. Please type the same password between \'new\' and \'confirmed\' box.";
var Js_msg127="Cannot accept space character in user name. Please try it again.";
var Js_msg128="Cannot accept space character in password. Please try it again.";
var Js_msg129="Invalid remote IP address";
var Js_msg130=" IP6 address invalid!";
var Js_msg131=" Can't input mac and remote mac at the same time!";
var Js_msg132="Can't input local and remote ip/port at the same time!";
var Js_msg133="User account is empty.\nDo you want to disable the password protection?";
var Js_msg134="Password cannot be empty. Please try again.";
var Js_msg135="Cannot accept space character in User Name. Please try again.";
var Js_msg136="Cannot accept space character in Password. Please try again.";
/*var Js_msg137='Please press the RST button for about 10 seconds to make the device reset to default settings.\nThen refer to the device case to find default User Name and Password.';*/
var Js_msg137='You should reset the device. Please press and hold the RST button for about 8-10 seconds, then release it.';
var Js_msg138="Cannot add the current access mac address, which will cause you to fail to connect to the router";
var Js_msg144="Is setting up and effective configuration!";
var Js_msg145="Invalid length of WEP  passphrase. It should be 5 or 10 characters. ";
var Js_msg146="Invalid MAC address. It should not be multicast MAC address between 01:00:5e:00:00:00 and 01:00:5e:7f:ff:ff.";
var password_passwd_unmatcheds = 'Password is not matched. Please type the same password.';
/****---util_gw.js***********/
var util_gw_invalid_gw_ip = 'Invalid Gateway address!';
var util_gw_locat_subnet = '\nIt should be located in the same Subnet of current IP address.';

/*****USB Function********/
var menu_usb='USB Functional';
var usb_header='USB functional Components';
var usb_dlna_enabled='Enable DLNA';
var usb_servername='Server Name';
var usb_samba_enabled='Enable SAMBA';
var usb_ftplocal_enabled='Enable FTP(Local)';
var usb_ftpremote_enabled='Enable FTP(Remote)';
var usb_user_name='User Name';
var usb_password='Password';
var usb_storage_information='USB Storage Information';
var usb_device_name='Device name';
var usb_Directory='Directory';
var usb_file_system='File System';
var usb_Total='Total';
var usb_Free='Free';
var usb_remove='Remove';
var Js_msg139='DLNA Server Name cannot be empty,please try again';
var Js_msg140='SAMBA User Name cannot be empty,please try again';
var Js_msg141='SAMBA Password cannot be empty,please try again';
var Js_msg142='FTP User Name cannot be empty,please try again';
var Js_msg143='FTP Password cannot be empty,please try again';



var BtSelecTitle="Select Download Folder";
var BtCreateFload="Create Floder in ";
var Js_btnewdirblank="Newly created download path cannot be empty";
var Js_btdownloadblank="Please select the download path";
var Js_btusenameblank="Please enter the offline page login user name";
var Js_btpsswdblank="Please set an offline page login password";
var Js_btinvalidwebport="BT offline login port range should be greater than 1024 less than 65535";

/*****USB End************/

//var Getting_IP_from_DHCP_server ="Getting IP from DHCP Server...";
var Getting_IP_from_DHCP_server ="DHCP <font color='#ff0000'>Disconnected</font>";
var DHCP_Connected="DHCP <font color='#0095c5'>Connected</font>";
var Fixed_IP_Connected="Static IP <font color='#0095c5'>Connected</font>";
var Fixed_IP_Disconnected="Static IP <font color='#ff0000'>Disconnected</font>";
var and_Fixed_IP_Connected="and Static IP <font color='#0095c5'>Connected</font>";
var and_Fixed_IP_Disconnected="and Static IP <font color='#ff0000'>Disconnected</font>";
var PPPoE_Connected1="PPPoE <font color='#0095c5'>Connected</font>";
var PPPoE_Disconnected1="PPPoE <font color='#ff0000'>Disconnected &nbsp;</font>";
var PPPoE_Connected2="PPPoE <font color='#0095c5'>Connected &nbsp;</font>";
var PPPoE_Disconnected2="PPPoE <font color='#ff0000'>Disconnected";
var PPPoE_Connected3="PPPoE <font color='#0095c5'>Connected</font>";
var PPPoE_Disconnected3="PPPoE <font color='#ff0000'>Disconnected";
var PPPoE_Connected4="PPPoE <font color='#0095c5'>Connected</font>";
var PPPoE_Disconnected4="PPPoE <font color='#ff0000'>Disconnected";
var PPPoE_Connected5="PPPoE <font color='#0095c5'>Connected</font>";
var PPPoE_Disconnected5="PPPoE <font color='#ff0000'>Disconnected";
var PPPoE_Connected6="PPPoE <font color='#0095c5'>Connected</font>";
var PPPoE_Disconnected_WAN_Not_Connected="PPPoE <font color='#ff0000'>Disconnected：WAN Disconnect &nbsp;</font>";
var PPPoE_Disconnected="PPPoE <font color='#ff0000'>Disconnected &nbsp;</font>";
var PPPoE_Disconnected_Authentication_Failed="PPPoE <font color='#ff0000'>Disconnected：User Name/Password Wrong &nbsp;</font>";
var PPPoE_Disconnected_Not_Found_PPPoE_Server="PPPoE <font color='#ff0000'>Disconnected：Not Found PPPoE Server &nbsp;</font>";
var PPPoE_Disconnected_No_response_from_the_Server_side="PPPoE <font color='#ff0000'>Disconnected：No response from the Server side &nbsp;</font>";
var and_Getting_IP_from_DHCP_server="<font color='#ff0000'>and Getting IP from DHCP server...</font>";
var and_DHCP="and DHCP";
var PPTP_Disconnected="PPTP <font color='#ff0000'>Disconnected</font>";
var PPTP_Connected="PPTP <font color='#0095c5'>Connected</font>";
var L2TP_Disconnected="L2TP <font color='#ff0000'>Disconnected</font>";
var L2TP_Connected="L2TP <font color='#0095c5'>Connected</font>";

/***********	reboot_schedule.htm	************/
var reboot_schedule_header = 'Reboot Schedule';
var reboot_schedule_explain = 'The schedule function allows you to setup the time that the router will reboot automatically.';
var reboot_schedule_enable = 'Reboot Schedule';
var reboot_schedule_everyday = 'Everyday';
var reboot_schedule_sun = 'Sun';
var reboot_schedule_mon = 'Mon';
var reboot_schedule_tue= 'Tue';
var reboot_schedule_wed = 'Wed';
var reboot_schedule_thu = 'Thu';
var reboot_schedule_fri = 'Fri';
var reboot_schedule_sat = 'Sat';
var reboot_schedule_24Hours = '24 Hours';
var reboot_schedule_from = 'From';
var reboot_schedule_to = 'To';
var reboot_schedule_save = 'Apply';
var reboot_schedule_reset = 'Reset';
var reboot_schedule_days = 'Days';
var reboot_schedule_time = 'Time';
var reboot_schedule_time_check = 'Please set the Days!';
var reboot_schedule_on='On';
var reboot_schedule_explain1='Error! Input value should be between 0-23 in decimal.';
var reboot_schedule_explain2='Error! Input value should be between 0-59 in decimal.';
var menu_reboot_schedule='Reboot Schedule';
var rebootschedule_hour = "(0-23 hour)";
var rebootschedule_min = "(0-59 min)";
var select_dis='Disable';
var select_enb='Enable';
var save_changes='Apply';
var qs_res='Refresh';

var menu_algSip='SIP ALG';
var menu_spiFwall='SPI Firewall';
var menu_nataddrmap='NAT Mapping';
var menu_statistics='Statistics';
/*************aliasip.htm*********************************/
var aliasip_header = 'Alias IP Setup';
var aliasip_explain = 'From this page you can register aliases to IP ports Access Point.';
var aliasip_enable = 'Enable Alias IP';
var aliasip_table = 'Alias IP Table';
var dhcp_ip = 'IP Address';
var route_tbl_inter = 'Interface ';
var route_tbl_select = 'Select';
var Add_New_Rule = "Add a rule(Max number of rule is 25)";
var Add_New_Rule_20 = "Add a rule(Max number of rule is 20)";
/**********************nat_addr_map.htm************/
var nataddrmap_header = 'NAT Mapping';
var nataddrmap_enable = 'Enable NAT Address Mapping';
var nataddrmap_publicip = 'Public IP Address';
var nataddrmap_privateip = 'Private IP Address';
var nataddrmap_comment = 'Comment';
var nataddrmap_table = 'Current NAT Address Mapping Table';
var nataddrmap_invalid_publicip = 'Invalid Public IP address';
var nataddrmap_invalid_privateip = 'Invalid Private IP address';
var route_deletechick_warn = 'Do you really want to delete the selected entry?';
var route_deleteall_warn = 'Do you really want to delete all entries?';
var route_deletechick = 'Delete Selected';
var route_deleteall = 'Delete All';

var scan_head ="Current Wireless IP/MAC List";
var scan_explain ="This page shows the wireless current IP/MAC table.";
var JS_max_entry_2 = "The maximum entry count is ";

/********************************stats.htm***********************/
var stats_explain = ' This page shows the packet counters for transmission and reception regarding to wireless and Ethernet networks.';
var stats_lan = ' LAN';
var stats_send = 'Sent Packets';
var stats_recv = 'Received Packets';
var stats_repeater = ' Repeater ';
var stats_eth = 'Ethernet';
var stats_wan = ' WAN';

var JS_ipConflict='This IP address conflicts with the IP address of the front-end device. Please try again.';
var JS_gateWayConflit='To avoid IP conflicts with the front-end router,your router IP adress has been changed to ';


var iptv_mode="IPTV MODE";
var iptv_port="IPTV PORT";
var wizard_IptvCustom="Custom";
var wizard_IptvBridge="Bridge";
var BT_Detect="Auto Detect";
var Js_CableDisconnect="No WAN access cable detected,please check!";
var Js_ScanPrimaryRouter="Scanned Primary Router";
var Js_Sitesurvey_On="Site-survey is running,please try later.";
var Js_SamePassword="Same as Primary Router Password";
var es_discn='Disconnected';

var Js_check_serverip_msg='Invalid Server IP address';
var Js_PrimaryRouterConnect="Primary Router Connection";
var Js_PrimaryRouterType="Primary Router Wireless Type";
var Js_PrimaryRouterWireless="Primary Router Wireless";
var Js_PrimaryRouterSsid="Primary Router SSID";
var Js_PrimaryRouterPw="Primary Router Password";
var wizard_msg1="User name cannot be empty, please try again.";
var wizard_msg2="Password cannot be empty, please try again.";
var wizard_msg3="Password is not matched，Please type the same password.";
var wizard_msg4="IP Address can’t be empty, please try again.";
var wizard_msg5="IP Address is invalid, please try again.";
var wizard_msg6="Subnet Mask is invalid, please try again.";
var wizard_msg7="Default Gateway cannot be empty, please try again.";
var wizard_msg8="Default Gateway is invalid, please try again.";
var wizard_msg9="Primary DNS cannot be empty, please try again.";
var wizard_msg10="Primary DNS is invalid, please try again.";
var wizard_msg11="Secondary DNS is invalid, please try again.";
var wizard_msg12="VPN Server/Domain Name cannot be empty, please try again.";
var wizard_msg13="SSID cannot be empty, please try again.";
var wizard_msg14="Password cannot be empty, please try again.";
var wizard_msg15="Please input the 8-63 ASCII characters .";
var wizard_msg16="Invalid password, please try again.";
var wizard_msg17="Applying Settings, please wait...";
var wizard_msg18="You have changed your wireless configuration, please connect to the new wireless SSID and continue to the next step.";
var wizard_wanConnType="WAN Connetction Type";
var wizard_wirelessNet="Wireless Network";
var wizard_opmode_msg1="Quickly configure the router to access the Internet.";
var wizard_opmode_msg2="Transform your existing wired network to a wireless network，Repeater's wireless password will be the same as the Primary Router.";
var wizard_opmode_msg3="Extend your existing wireless coverage by relaying wireless signal.";
var wizard_opmode_msg4="In this mode, the device enables multiple users to access the Internet from WISP. All connected terminals share the same IP through wireless connection.";
var MacAddrNote="(MAC Format: 112233aabbcc)";
var Verification_Code="Verification Code";
var Wifi_SiteNote="Please Input The Upper level AP's Password!";

var upgrading_note="Note：";
var upgrading_note1="1.DO NOT power off the device during firmware upgrade. ";
var upgrading_note2="2.DO reset the router to factory default settings by RST or RST/WPS button after firmware upgrade is finished.";
var wps_success="Start PBC successfully!\nYou have to run Wi-Fi Protected Setup in client within 2 minutes.";
var wps_stop="Applied WPS STOP successfully!";
var wps_pin_success="Applied WPS PIN successfully!\nYou have to run Wi-Fi Protected Setup within 2 minutes.";

var lgok="Success!";
var status_wifi_mod="Local AP";
var scan_mac_bt="Scan MAC Address";
var alert_err_dns1="DNS1 address cannot be empty!";
var alert_subnet_empty="Subnet mask cannot be empty! It should be filled with 4 digit numbers as xxx.xxx.xxx.xxx.";
var wlan_restrict_show="Mbps(0:Unlimit)";
var radius_server_ip="RADIUS Server IP Address";
var radius_server_port="RADIUS Server Port";
var radius_server_paawd="RADIUS Server Password";
var alert_psk_less8="Pre-Shared Key value should be set at least 8 characters.";
var radius_ip_empty="No RS IP address!";
var wlsch_hour_show="(hour)";
var wlsch_minute_show="(min)";
var portfw_port_show="(1-65535,XX or XX-XX)";
var portfw_operation="Operation";
var portfw_error1="Invalid format, Please enter a value of 1-65535.";
var ntp_date="Date";
var ntp_time="Time";
var ddns_uptime_err="Invalid value of ddns's update time. Input value should be between 1-14400 in decimal.";
var syslog_dos="DoS";
var ntp_Mdy="(MM/DD/YYYY)";
var ntp_Hms="(HH/MM/SS)";

var reset_sr="The system is restored to factory settings";
var reset_ss="Setting successfully!";
var IP_link="IP link";
var PPP_link="PPP link";

var status_reboot = "Reboot Router";
var MM_Static_Gateway="Gateway";
var wechat_check_net="Please check the network connection!";
var MM_upload_save="Do not retain configuration";
var MM_statrfw_note1="Update tip: ";
