<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><% getInfo("home_title"); %></title>
<link rel="shortcut icon" href="../favicon.ico">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/csstyle.css">
<script language="javascript" src="<%getInfo("langFileName");%>"></script>
<style>
		.has-feedback .form-control{


			padding-right: 0;
			padding-left: 34px;


		}
		.form-control-feedback {
			left: 0;
			top: 25px !important;
			color: #999;
		}
		
		
	</style>
</head>
<body>
	<div class="container-fluid" id="div_login" style="display:none">
		<div class="container" align="center">
        	<div class="cs-h-30"></div>
			<img src="img/logo.png" class="img-responsive cs-logo">
		</div>
        
		<div id="cs_login" >
            <div class="cs-h-30"></div>
            <div class="container col-xs-10 col-xs-offset-1">
                <div align="center">
                	<span class="cs-font-36">Welcome</span>
                </div>
                <div class="cs-h-30"></div>
                <form method="post" id="login_frm" name="login_frm" action="/boafrm/formLogin">
                <div class="form-group has-feedback">
                    <label for="username"><script>dw(MB_username)</script></label>
                    <span class="form-control-feedback"><i class="glyphicon glyphicon-user"></i></span>
                    <input type="text" class="form-control input-sm" id="username" name="username" maxlength="32" onFocus="clean_err()">
                </div>
                <div class="form-group has-feedback">
                    <label for="password"><script>dw(MB_password)</script></label>
                    <span class="form-control-feedback"><i class="glyphicon glyphicon-lock"></i></span>
                    <input type="password" class="form-control input-sm" id="password" name="password" maxlength="32" onFocus="clean_err()" onChange="$('#cs_login_btn').click();">
                </div>
				<div class="form-group" id="div_err" style="display: none;">
					<label class="cs-err" id="err_msg"></label>
				</div>
				<div class="form-group" align="right">
					<a class="cs-font-white cs-a-link" id="cs_forgot_btn"><script>dw(MB_forgot)</script></a>
				</div>				
                <div class="cs-h-10"></div>
                <div class="row">
                    <div class="col-xs-8 col-xs-offset-2">
                    	<button type="button" class="btn btn-block btn-cs-black" id="cs_login_btn"><script>dw(BT_Login)</script></button>
                    </div>
                </div>				
                </form>
                <div class="cs-h-20"></div>
            </div>
		</div>
	</div>

<script language="javascript" src="/js/jquery.min.js"></script>
<script language="javascript" src="js/bootstrap.min.js"></script>
<script language="javascript" src="js/mobile.js"></script>
<script language="javascript" src="js/router.js"></script>
<script>

if(top!=self)top.location.href = self.location.href;
$(function() {
var lang_org;
var isDefZh_ScAndTc=<%getIndex("IsDefZh_ScAndTc");%>;
var weblang=<%getIndex("webLang");%>;
        //auto lang
if (weblang == 0)
lang_org="en";
else if (weblang == 1)
{
	if(isDefZh_ScAndTc==1)
		lang_org="zh_tc";
	else
		lang_org="zh";
}
else if (weblang == 2)
lang_org="ru";
else if (weblang == 3)
lang_org="vi";
else if (weblang == 5)
lang_org="zh";
else
lang_org="en";

	if ('<%getIndex("webLangAuto")%>' == "lang-auto-ON") {
		var lang = navigator.language||navigator.userLanguage;
		
		var langstr=lang.substr(0, 5);
		if(((-1!=langstr.indexOf("zh-TW"))  || (-1!=langstr.indexOf("zh-HK"))) && (isDefZh_ScAndTc==1))
			lang="zh_tc";
		else
			lang = lang.substr(0, 2); 

		var postVar={"topicurl":"setting/setLangConfig"};
		postVar['navigatorLang']=lang;
if((lang==lang_org)  || ((lang!="zh") && (lang!="en") && (lang!="vi") && (lang!="ru") && (lang!="zh_tc") && (lang_org=="en")))
		{
			$('#div_login').show();
		}
		postVar=JSON.stringify(postVar);
		$.ajax({
			type : "post", url : " /boafrm/formLogin", data : postVar, async : false, dataType : "script"
		});
	}
	else
	{
		$('#div_login').show();
	}
	// getLoginCfg();
	$('#cs_login_btn').on('click', function(event) {
		if($("#username").val()==""||$("#password").val()==""){
			$('#err_msg').html(JS_msg51);
			$('#div_err').show();
			return false;
		}

		var postVar={"topicurl":"setting/setUserLogin"};
		postVar['username']=$("input[name='username']").val();
		postVar['userpass']=$("input[name='password']").val();
		postVar=JSON.stringify(postVar);
		
		
		

		
		$.ajax({
			type : "post", url : "/boafrm/formLogin", data : postVar, async : false,
			success : function(Data){
				if(Data.length == 0) {
					
					parent.location="home.asp";
				}
				else {
                                        window.eval(Data);
					return false;
				}
			}
		});
		
	
		return true;
	});
	
	$('#cs_forgot_btn').on('click', function(event) {
		gotoUrl('forgot.asp');
	});
});

function clean_err(){
	$("#div_err").hide();
}
</script>
</body>
</html>
