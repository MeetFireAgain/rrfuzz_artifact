<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<!-- HTTP 1.1 -->  
<meta http-equiv="pragma" content="no-cache">  
<!-- HTTP 1.0 -->  
<meta http-equiv="cache-control" content="no-cache">  
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><% getInfo("home_title"); %></title>
<link rel="shortcut icon" href="../favicon.ico">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/csstyle.css">
<script language="javascript" src="<%getInfo("langFileName");%>"></script>
</head>
<body>
    <input type="hidden" id="wantype">
    <input type="hidden" id="pppoe_user">
    <input type="hidden" id="pppoe_pass">
    <input type="hidden" id="wanip">
    <input type="hidden" id="wanmask">
    <input type="hidden" id="wangw">
    <input type="hidden" id="wandns">
	<div class="container-fluid" id="cs_body_wifi">
		<div class="row cs-header">
			<h4><i class="glyphicon glyphicon-asterisk"></i><script>dw(MB_wifi_setting)</script></h4>
		</div>
        
		<div id="cs_wifi">
            <div class="cs-h-30"></div>
            <div class="container">
                <form class="">
                <div class="form-group">
                    <label>2.4G <script>dw(MB_wifi_setting)</script></label>
                </div>	
                <div class="form-group">
                    <label class="cs-font-normal" for="wifissid"><script>dw(MB_wifi_ssid)</script></label>
                    <input type="text" class="form-control input-sm" id="wifissid" maxlength="32">
                </div>
                <div class="form-group has-feedback">
                    <label class="cs-font-normal" for="wifikey"><script>dw(MB_wifi_pass)</script></label>
                    <span id="switch_eye" class="pos-right"><i class="glyphicon glyphicon-eye-open"></i></span>
                    <input type="text" class="form-control input-sm" id="wifikey" maxlength="63">
                </div>
				<% getInfo("html_mobile5G_s"); %>	
                <div class="cs-h-20"></div>
                <div class="form-group">
                    <label>5G <script>dw(MB_wifi_setting)</script></label>
                </div>	
                <div class="form-group">
                    <label class="cs-font-normal" for="wifi5gssid"><script>dw(MB_wifi_ssid)</script></label>
                    <input type="text" class="form-control input-sm" id="wifi5gssid" maxlength="32">
                </div>
                <div class="form-group has-feedback">
                    <label class="cs-font-normal" for="wifi5gkey"><script>dw(MB_wifi_pass)</script></label>
                    <span id="switch_eye5g" class="pos-right"><i class="glyphicon glyphicon-eye-open"></i></span>
                    <input type="text" class="form-control input-sm" id="wifi5gkey" maxlength="63">
                </div>
				<% getInfo("html_mobile5G_e"); %>
                <div class="form-group" id="pwd_msg">
                    <label class="cs-font-normal"><script>dw(MB_pwd_length)</script></label>
                </div>
                <div class="form-group" id="div_err">
                    <label class="cs-font-normal" id="err_msg"></label>
                </div>
                <div class="cs-h-20"></div>
                <div class="row">
                    <div class="col-xs-6"><button type="button" class="btn btn-block btn-default" onClick="doBack()"><script>dw(BT_Back)</script></button></div>
                    <div class="col-xs-6"><button type="button" class="btn btn-block btn-cs-black" onClick="doPost()"><script>dw(MB_done)</script></button></div>
                </div>
                </form>
            </div>
		</div>
	</div>

    <div class="container-fluid" id="cs_result" style="display: none;">
        <div id="cs_connect">
            <div class="cs-h-200"></div>
            <div class="container col-xs-10 col-xs-offset-1">
                <div align="center">
                    <img src="img/connecting.png" class="img-responsive cs-img-6">
                    <div class="cs-h-10"></div>
                    <div class="result_bar">
                        <div id="result_bar" ></div>
                    </div>
                    <div class="cs-h-10"></div>
                    <h5><script>dw(MB_apply)</script></h5>
                </div>
            </div>
        </div>

        <!-- Successful -->
        <div id="cs_success" style="display:none">
            <div class="container" align="center">
                <div class="cs-h-30"></div>
                <img src="img/connect_on.png" class="img-responsive cs-img" style="width: 30%" >
            </div>
            <div class="cs-h-30"></div>
            <div class="container">
                <div align="center">
                    <h4><script>dw(MB_success)</script></h4>
                </div>
                <div class="cs-h-10"></div>
                <div align="center">
                    <span><script>dw(MB_changed)</script></span>
                </div>
            </div>
            <div class="cs-h-30"></div>
            <div class="container">
                <div class="h4" style="border-bottom: 1px solid #fff; padding-bottom: 5px; "><script>dw(MB_wifi)</script> 2.4GHZ</div>
                <div class="row">
                    <div class="col-xs-4"><script>dw(MB_wifi_ssid)</script></div>
                    <div class="col-xs-8" id="wifi_ssid"></div>
                </div>
                <div class="row">
                    <div class="col-xs-4"><script>dw(MB_wifi_pass)</script></div>
                    <div class="col-xs-8" id="wifi_pass"></div>
                </div>
				<% getInfo("html_mobile5G_s"); %>
                <div class="cs-h-20"></div>
                <div class="h4" style="border-bottom: 1px solid #fff; padding-bottom: 5px; "><script>dw(MB_wifi)</script> 5GHz</div>
                <div class="row">
                    <div class="col-xs-4"><script>dw(MB_wifi_ssid)</script></div>
                    <div class="col-xs-8" id="wifi5g_ssid"></div>
                </div>
                <div class="row">
                    <div class="col-xs-4"><script>dw(MB_wifi_pass)</script></div>
                    <div class="col-xs-8" id="wifi5g_pass"></div>
                </div>
				<% getInfo("html_mobile5G_e"); %>
            </div>
            <div class="cs-h-30"></div>
            <div style="display: none;">
                <button type="button" class="btn btn-block btn-cs-black" style="margin-left: 25%;width: 50%;" id="cs_ok_btn" align="center"><script>dw(BT_OK)</script></button>
            </div>
            <div class="cs-h-20"></div>
        </div>
        <!-- /. Successful -->

        <!-- Failed -->
        <div id="cs_fail" style="display:none">
        <div class="container col-xs-10 col-xs-offset-1">
            <div class="container" align="center">
                <div class="cs-h-30"></div>
                <img src="img/connect_off.png" class="img-responsive cs-img">
            </div>
            <div class="cs-h-30"></div>
            <div class="container">
                <div align="center">
                    <h5><script>dw(MB_fail)</script></h5>
                    <h5><script>dw(MB_configure)</script></h5>
                </div>   
            </div>        
            <div class="cs-h-30"></div>
            <div class="row">
                <div class="col-xs-8 col-xs-offset-2">
                    <button type="button" class="btn btn-block btn-cs-black" id="cs_again_btn"><script>dw(BT_TryAgain)</script></button>
                </div>
            </div>
            <div class="cs-h-20"></div>
        </div>
        </div>
        <!-- /. Failed -->
    </div>
<script language="javascript" src="/js/jquery.min.js"></script>
<script language="javascript" src="js/bootstrap.min.js"></script>
<script language="javascript" src="js/mobile.js"></script>
<script language="javascript" src="js/router.js"></script>
<script>
var sessionid='<% getInfo("session-code"); %>';
function doBack() {
	history.go(-1);
}
var wlan_num=<%getIndex("wlan_num");%>;
function doPost() {

	if (!IsValidStr($('#wifissid'),"2.4G "+MB_wifi_ssid,1)) return false;
	if (!IsValidStr($('#wifikey'),"2.4G "+MB_wifi_pass,2)) return false;
if(wlan_num >1)			
{	
	if (!IsValidStr($('#wifi5gssid'),"5G "+MB_wifi_ssid,1)) return false;
	if (!IsValidStr($('#wifi5gkey'),"5G "+MB_wifi_pass,2)) return false;
}
	$('#cs_wifi').hide();
	$('#cs_connect').show();

	$("#cs_result", parent.document).show();
	$("#cs_body_wifi", parent.document).hide();
	setWizardCfg(<% getIndex("wlan_num"); %>);
}

$(function() {
	//getWizardCfg(2);

	if ('<%getIndex("webLangAuto");%>' == "lang-auto-ON") 
	{
		var lang = navigator.language||navigator.userLanguage;
		var langstr=lang.substr(0, 5);
		if((-1!=langstr.indexOf("zh-TW"))  || (-1!=langstr.indexOf("zh-HK")))
			lang="zh_tc";
		else
			lang = lang.substr(0, 2); 

		var postVar={"topicurl":"setting/setLangConfig"};
		postVar['navigatorLang']=lang;
		postVar['sessionCheck']=sessionid;	
		postVar=JSON.stringify(postVar);	
		
		$.ajax({
			type : "post", url : " /boafrm/formLogin", data : postVar, async : false, dataType : "script"
		});
	}

	var url_href = location.hash.substr(1);
	var url_href = url_href.split('&');
	for (var i = 0; i < url_href.length; i++) {
		url_href[i] = url_href[i].split('=');
	};
	if(0 == url_href[0][1]){//Static
		$("#wantype").val("0");
		$("#wanip").val(url_href[1][1]);
		$("#wanmask").val(url_href[2][1]);
		$("#wangw").val(url_href[3][1]);
		$("#wandns").val(url_href[4][1]);
	}else if(3 == url_href[0][1]){//PPPoE
		$("#wantype").val("3");
		$("#pppoe_user").val(url_href[1][1]);
		$("#pppoe_pass").val(url_href[2][1]);
	}else{//DHCP
		$("#wantype").val("1");
	}

	$('#switch_eye').on('click', function(event) {
		var $i_element = $(this).find('i');
		if ($i_element.hasClass('glyphicon-eye-open')) {
			$i_element.removeClass('glyphicon-eye-open').addClass('glyphicon-eye-close');
			$('#wifikey').attr('type','text');
		} else {
			$i_element.removeClass('glyphicon-eye-close').addClass('glyphicon-eye-open');
			$('#wifikey').attr('type','password');
		}
	});	
	if(wlan_num >1)	
	{
	$('#switch_eye5g').on('click', function(event) {
		var $i_element = $(this).find('i');
		if ($i_element.hasClass('glyphicon-eye-open')) {
			$i_element.removeClass('glyphicon-eye-open').addClass('glyphicon-eye-close');
			$('#wifi5gkey').attr('type','text');
		} else {
			$i_element.removeClass('glyphicon-eye-close').addClass('glyphicon-eye-open');
			$('#wifi5gkey').attr('type','password');
		}
	});	
	}

	$('#cs_ok_btn').on('click', function(event) {
		if (navigator.userAgent.indexOf("Firefox") != -1 || navigator.userAgent.indexOf("Chrome") !=-1) {
			location.href="about:blank";
			close();
		} else {
			opener = null;
			open("", "_self");
			close();
		}
	});
});
</script>
<iframe src="../wizard.htm" id="savetmpconf" style="display:none;" width="100%" height="500"></iframe>
</body>
</html>
