<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<script language="javascript" src="<%getInfo("langFileName");%>"></script>
<link href='../style.css' rel='stylesheet' type='text/css'>
<script src='",langFile(),"'></script>
<script src='../util_gw.js'></script>
<script src='../js/jquery.min.js'></script>
</head>
<body><blockquote><h4>success!</h4>
<form><input type="button" onclick="window.open('about:blank','_self')" value="&nbsp;&nbsp;OK&nbsp;&nbsp;" name="OK">
</form>
</blockquote>
</body>
</html>
