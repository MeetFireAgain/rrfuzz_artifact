var setWizardCfg_flag = 0;
function getStatusCfg(){
	var postVar={"topicurl" : "getting/getModelFw"};
	postVar['sessionCheck']=sessionid;
	postVar=JSON.stringify(postVar);
	$.ajax({  
		type : "post", url : "/boafrm/formAjaxGet", data : postVar, async : false, success : function(Data){
			var rJson=JSON.parse(Data);
			setJSONValue({
				'productModel' :   rJson['productName'],
				'fmVersion'  :   rJson['fmVersion']
			});
		}
	});   
}

function getLoginCfg(){
    var postVar={"topicurl" : "setting/getLanguageCfg"};
    postVar['sessionCheck']=sessionid;
    postVar=JSON.stringify(postVar);
    $.ajax({  
        type : "post", url : " /cgi-bin/cstecgi.cgi", data : postVar, async : false, success : function(Data){
            var rJson=JSON.parse(Data);
            if (rJson["loginFlag"]==1){
                $('#err_msg').html(JS_msg52);
            }else{
                $('#err_msg').html("");
            }
        }
    });   
}

function getDial(val){
    var postVar={"topicurl" : "setting/getSpeeddial"};
    postVar=JSON.stringify(postVar);
    $.ajax({  
        type : "post", url : " /cgi-bin/cstecgi.cgi", data : postVar, async : true, success : function(Data){
            var rJson=JSON.parse(Data);
			setJSONValue({
				'myip'    :   rJson['NewWanIP'],
				'mymask'  :   rJson['NewWanMsk'],
				'mygw'    :   rJson['NewWanGW'],
				'mydns'   :   rJson['NewWanPriDns']
			});
        }
    });
}

function startDial(){
    var postVar={"topicurl":"setting/setSpeeddial"};
    postVar=JSON.stringify(postVar);
    $.post(" /cgi-bin/cstecgi.cgi",postVar,function(Data){setTimeout('getDial("DHCP");',500);});
    setTimeout('location.href="internet.asp?ret=1"',1000);
}

function getWizardCfg(flag){
    var postVar={"topicurl" : "setting/getEasyWizardCfg"};
    postVar['sessionCheck']=sessionid;
    postVar=JSON.stringify(postVar);
    if(flag==1){
        $.ajax({  
            type : "post", url : " /cgi-bin/cstecgi.cgi", data : postVar, async : false, success : function(Data){
                var rJson=JSON.parse(Data);  
				setJSONValue({
					'lanip'     	:   rJson['lanIP'],
					'pppoe_user'    :   rJson['pppoeUser'],
					'pppoe_pass'    :   rJson['pppoePass'],
					'myip'    		:   rJson['wanIP'],
					'mymask'  		:   rJson['wanMask'],
					'mygw'    		:   rJson['wanGW'],
					'mydns'   		:   rJson['wanPriDns'],
					'wanip'     	:   rJson['staticIP'],
					'wanmask'   	:   rJson['staticMsk'],
					'wangw'     	:   rJson['staticGW'],
					'wandns'    	:   rJson['wanPriDns']
				});
				if($("#wanip").val()==""){
					supplyValue("wandns","");
				}
				if(rJson['wanConnMode']==3){
					$($('#cs_tab').find('.btn')[0]).parent().addClass('active').siblings().removeClass('active');
					$("#tab_dhcp,#tab_static").hide();
					$("#tab_pppoe").show();
				}else if(rJson['wanConnMode']==0){
					$($('#cs_tab').find('.btn')[2]).parent().addClass('active').siblings().removeClass('active');
					$("#tab_dhcp,#tab_pppoe").hide();
					$("#tab_static").show();
				}else{
					$($('#cs_tab').find('.btn')[1]).parent().addClass('active').siblings().removeClass('active');
					$("#tab_static,#tab_pppoe").hide();
					$("#tab_dhcp").show();
				}
            }
        });         
	}else{
        $.ajax({  
            type : "post", url : " /cgi-bin/cstecgi.cgi", data : postVar, async : false, success : function(Data){
                var rJson=JSON.parse(Data);  
				setJSONValue({
					'wifissid'   :   rJson['wifiSSID'],
					'wifikey'    :   rJson['wifiWPAPSK'],
					'wifi5gssid' :   rJson['wifiSSID5g'],
					'wifi5gkey'  :   rJson['wifiWPAPSK5g']
				});
            }
        }); 
    }
}

function setWizardCfg(wlan_num) {
	var obj=document.getElementById('savetmpconf').contentWindow.document;
	var objFuc=document.getElementById('savetmpconf').contentWindow.window;

	//alert($('#wantype').val());
	var wanType = $('#wantype').val();
	if( wanType == 0 ){
		obj.getElementById('wanType').value = "fixedIp";

		obj.getElementById('wan_ip').value = $('#wanip').val();
		obj.getElementById('wan_mask').value = $('#wanmask').val();
		obj.getElementById('wan_gateway').value = $('#wangw').val();
		obj.getElementById('dns1').value = $('#wandns').val();
	}
	if( wanType == 1 ){
		obj.getElementById('wanType').value = "autoIp";
	}
	if( wanType == 3 ){
		obj.getElementById('wanType').value = "ppp";

		obj.getElementById('pppUserName').value = $('#pppoe_user').val();
		obj.getElementById('pppPassword').value = $('#pppoe_pass').val();
	}
	objFuc.wanTypeSelection(obj.wizard.wanType);
	objFuc.setMobileWl();

	objFuc.SubmitAllData();
}
