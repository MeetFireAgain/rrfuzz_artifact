function dw(key){document.write(key);}
//---------------for button-------------------
var BT_Back="Back";
var BT_Next="Next";
var BT_OK="OK";
var BT_TryAgain="Try again";
var BT_Login = "Login";
//---------------for message-------------------
var JS_msg44="The WAN IP address you set is invalid, it can not be the same as the current LAN IP address, or in the same segment!";
var JS_msg51="The User Name and Password cannot be empty.";
var JS_msg52="The User Name or Password is wrong.";
var lgerr6="User Name is error";//使用者名稱錯誤
var lgerr8="Password is error";//密碼錯誤
var lgerr10="Input error three times, please wait 2 minutes to try again";//登入三次失敗,請稍待2分鐘後再次嘗試登入。

var lgerr13="Users have logged in from other browsers on this device. You can't log in with different browsers at the same time. Please try again later or login through the browser you used last time.";
var lgerr14="User is logined from";
var lgerr15="You can't login on different devices at the same time. Please try again later or login through the device and browser you used last time.";
//---------------for mobile-------------------
var MB_back = "Back";
var MB_username = "User Name";
var MB_password = "Password";
var MB_forgot = "Forgot Password";

var MB_reset = "Please reset the router to factory default settings !";
var MB_operation = "Operation:";
var MB_quickly = "Keep pressing the router's RST button until the CPU indicator flashes quickly.";
var MB_def_name = "Default User Name";
var MB_def_pass = "Default User Password";

var MB_router_setting = "TOTOLINK Router Setting";
var MB_model_no = "Model No";
var MB_version = "F/W Version";
var MB_quick_setup = "Quick Setup";
var MB_advanced_setup = "Advanced Setup";

var MB_wating = "Auto-detecting the Internet Connetction Type...";
var MB_not_con = "The WAN port is not connected";
var MB_skip = "Skip";

var MB_wan_setting = "WAN Setting";
var MB_pppoe = "PPPoE";
var MB_dhcp = "Dynamic IP";
var MB_static = "Static IP";
var MB_pppoe_user = "User Name";
var MB_pppoe_pass = "Password";
var MB_ip = "IP Address";
var MB_mask = "Subnet Mask";
var MB_gw = "Gateway";
var MB_dns_ser = "DNS Server";
var MB_isp_info = "Please enter User Name and Password by your ISP";
var MB_wan_status = "WAN Status";
var MB_dhcp_info = "An IP confict is detected between yhe router and upper device, the router's IP address will be changed to ";
var MB_static_info = "Please cmplete beleow information";
var MB_ip_info = "IP Address error!";
var MB_mask_info = "Subnet Mask error!";
var MB_gw_info = "Gateway Address error!";
var MB_dns_info = "DNS Server error!";
var MB_pppoe_user_info = "User Name can not be empty!";
var MB_pppoe_pass_info = "Password can not be empty!";

var MB_wifi = "Wireless";
var MB_wifi_setting = "Wi-Fi Setting";
var MB_wifi_ssid = "Network Name (SSID)";
var MB_wifi_pass = "Password";
var MB_pwd_length = "Length range is 8-63";
var MB_pwd_err = "Password setting error!";

var MB_apply = "Applying...";
var MB_success = "Router Setup Complete";
var MB_changed = "Since Wi-Fi setting changed, you device will lose connection to the router. Please reconnect.";
var MB_fail = "Router configurtion failed";
var MB_configure = "palease check all settings and re-configure the router.";
var MB_done = "Finish";

var MB_msg_1 = " can not be empty!";
var MB_msg_2 = " is invalid.";
var MB_msg_3 = " can not be the same as the router's IP!";
var MB_msg_4 = " is invalid. \nOnly allowed to include special characters!@#^&*()+_-={}[]::.?' and space characters.";
var MB_msg_5 = " is invalid. \nOnly allowed to include special characters!@#^&*()+_-={}[]::.?'";

var lgok="Success!";
var MB_welcome="Welcome";
